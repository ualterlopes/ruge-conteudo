"""Drawing helpers for the RUGE + Nexo teaser (skia-python, 1080x1920)."""
import os, math
import numpy as np
import skia

W, H, FPS = 1080, 1920, 30
HERE = os.path.dirname(os.path.abspath(__file__))
FD = os.path.join(HERE, 'fonts')

# ---------------------------------------------------------------- palette (RUGE: dark ground, ivory line, contained orange)
IVORY = (240, 231, 213)
ORANGE = (232, 124, 50)
GREY = (150, 140, 126)
BG_C = (27, 23, 20)
BG_E = (7, 6, 5)
CARD = (30, 26, 22)
SCREEN = (15, 13, 11)
INK = (12, 10, 9)


def C(rgb, a=1.0):
    a = 0.0 if a < 0 else (1.0 if a > 1 else a)
    return skia.Color4f(rgb[0] / 255.0, rgb[1] / 255.0, rgb[2] / 255.0, a)


def CI(rgb, a=1.0):
    a = 0.0 if a < 0 else (1.0 if a > 1 else a)
    return skia.ColorSetARGB(int(round(a * 255)), int(rgb[0]), int(rgb[1]), int(rgb[2]))


def mixc(c1, c2, k):
    return tuple(c1[i] + (c2[i] - c1[i]) * k for i in range(3))


# ---------------------------------------------------------------- fonts
FN = {'cond': 'BarlowCondensed-SemiBold.ttf', 'condm': 'BarlowCondensed-Medium.ttf', 'condb': 'BarlowCondensed-Bold.ttf',
      'condr': 'BarlowCondensed-Regular.ttf', 'sans': 'Barlow-Regular.ttf', 'sansm': 'Barlow-Medium.ttf',
      'sanssb': 'Barlow-SemiBold.ttf', 'serif_i': 'InstrumentSerif-Italic.ttf', 'serif': 'InstrumentSerif-Regular.ttf'}
_TF, _FC = {}, {}


def font(kind, size):
    key = (kind, round(size, 1))
    f = _FC.get(key)
    if f is None:
        if kind not in _TF:
            _TF[kind] = skia.Typeface.MakeFromFile(os.path.join(FD, FN[kind]))
        f = skia.Font(_TF[kind], key[1])
        f.setSubpixel(True)
        f.setEdging(skia.Font.Edging.kAntiAlias)
        f.setHinting(skia.FontHinting.kNone)
        f.setLinearMetrics(True)
        if len(_FC) < 6000:
            _FC[key] = f
    return f


# ---------------------------------------------------------------- easing
def cl(x, a=0.0, b=1.0):
    return a if x < a else (b if x > b else x)


def pr(t, t0, d):
    return cl((t - t0) / d) if d > 0 else (1.0 if t >= t0 else 0.0)


def eo(x):
    x = cl(x); return 1 - (1 - x) ** 3


def eo4(x):
    x = cl(x); return 1 - (1 - x) ** 4


def ei(x):
    x = cl(x); return x ** 3


def eio(x):
    x = cl(x); return 4 * x ** 3 if x < .5 else 1 - (-2 * x + 2) ** 3 / 2


def eob(x, c=1.7):
    x = cl(x); return 1 + (c + 1) * (x - 1) ** 3 + c * (x - 1) ** 2


def lerp(a, b, k):
    return a + (b - a) * k


# ---------------------------------------------------------------- paints
_CAPS = {'round': skia.Paint.kRound_Cap, 'butt': skia.Paint.kButt_Cap, 'square': skia.Paint.kSquare_Cap}


def PS(rgb, a, w, blur=0.0, cap='round', dash=None, phase=0.0):
    p = skia.Paint()
    p.setAntiAlias(True)
    p.setStyle(skia.Paint.kStroke_Style)
    p.setStrokeWidth(w)
    p.setColor4f(C(rgb, a))
    p.setStrokeCap(_CAPS[cap])
    p.setStrokeJoin(skia.Paint.kRound_Join)
    if blur > 0:
        p.setMaskFilter(skia.MaskFilter.MakeBlur(skia.kNormal_BlurStyle, blur))
    if dash:
        p.setPathEffect(skia.DashPathEffect.Make(list(dash), phase))
    return p


def PF(rgb, a, blur=0.0):
    p = skia.Paint()
    p.setAntiAlias(True)
    p.setStyle(skia.Paint.kFill_Style)
    p.setColor4f(C(rgb, a))
    if blur > 0:
        p.setMaskFilter(skia.MaskFilter.MakeBlur(skia.kNormal_BlurStyle, blur))
    return p


# ---------------------------------------------------------------- paths
def contour_lengths(path):
    pm = skia.PathMeasure(path, False)
    L = []
    while True:
        L.append(pm.getLength())
        if not pm.nextContour():
            break
    return L


def trim(path, p1, p0=0.0, mode='seq'):
    L = contour_lengths(path)
    tot = sum(L)
    out = skia.Path()
    if tot <= 0:
        return out
    pm = skia.PathMeasure(path, False)
    acc = 0.0
    for l in L:
        if mode == 'seq':
            a, b = max(p0 * tot - acc, 0.0), min(p1 * tot - acc, l)
        else:
            a, b = p0 * l, p1 * l
        if b > a + 0.01:
            seg = skia.Path()          # skia-python's getSegment overwrites dst, so collect per contour
            pm.getSegment(a, b, seg, True)
            out.addPath(seg)
        acc += l
        if not pm.nextContour():
            break
    return out


def point_at(path, frac):
    L = contour_lengths(path)
    tot = sum(L)
    d = cl(frac) * tot
    pm = skia.PathMeasure(path, False)
    acc = 0.0
    for i, l in enumerate(L):
        if d <= acc + l or i == len(L) - 1:
            pos, tan = pm.getPosTan(cl(d - acc, 0, l))
            return (pos.x(), pos.y()), (tan.x(), tan.y())
        acc += l
        pm.nextContour()
    return (0.0, 0.0), (1.0, 0.0)


def spath(c, path, rgb, a, w, p=1.0, p0=0.0, glow=0.0, mode='seq', dash=None, phase=0.0, cap='round'):
    """stroke a path, optionally trimmed (draw-on) and with a soft glow"""
    if a <= 0.004 or p <= p0 + 1e-4:
        return None
    tp = path if (p >= 0.9999 and p0 <= 1e-4) else trim(path, p, p0, mode)
    if glow > 0:
        c.drawPath(tp, PS(rgb, a * glow * 0.40, w * 3.4, blur=w * 2.6, cap=cap, dash=dash, phase=phase))
        c.drawPath(tp, PS(rgb, a * glow * 0.35, w * 1.6, blur=w * 0.8, cap=cap, dash=dash, phase=phase))
    c.drawPath(tp, PS(rgb, a, w, cap=cap, dash=dash, phase=phase))
    return tp


def rrect(x, y, w, h, r):
    return skia.RRect.MakeRectXY(skia.Rect.MakeXYWH(x, y, w, h), r, r)


def rrect_path(x, y, w, h, r, start_top=True):
    """rounded rect as a path starting at the top centre (nicer draw-on)"""
    r = min(r, w / 2, h / 2)
    p = skia.Path()
    cx = x + w / 2
    p.moveTo(cx, y)
    p.lineTo(x + w - r, y)
    p.arcTo(skia.Rect.MakeXYWH(x + w - 2 * r, y, 2 * r, 2 * r), -90, 90, False)
    p.lineTo(x + w, y + h - r)
    p.arcTo(skia.Rect.MakeXYWH(x + w - 2 * r, y + h - 2 * r, 2 * r, 2 * r), 0, 90, False)
    p.lineTo(x + r, y + h)
    p.arcTo(skia.Rect.MakeXYWH(x, y + h - 2 * r, 2 * r, 2 * r), 90, 90, False)
    p.lineTo(x, y + r)
    p.arcTo(skia.Rect.MakeXYWH(x, y, 2 * r, 2 * r), 180, 90, False)
    p.lineTo(cx, y)
    return p


def circle_path(cx, cy, r, start=-90):
    p = skia.Path()
    p.addArc(skia.Rect.MakeXYWH(cx - r, cy - r, 2 * r, 2 * r), start, 359.99)
    return p


def arc_path(cx, cy, r, start, sweep):
    p = skia.Path()
    p.addArc(skia.Rect.MakeXYWH(cx - r, cy - r, 2 * r, 2 * r), start, sweep)
    return p


def poly(pts, close=False):
    p = skia.Path()
    p.moveTo(*pts[0])
    for q in pts[1:]:
        p.lineTo(*q)
    if close:
        p.close()
    return p


def cubic(p0, c1, c2, p1):
    p = skia.Path()
    p.moveTo(*p0)
    p.cubicTo(*c1, *c2, *p1)
    return p


def glow_blob(c, cx, cy, r, rgb, a):
    if a <= 0.002:
        return
    paint = skia.Paint()
    paint.setShader(skia.GradientShader.MakeRadial(skia.Point(cx, cy), r, [CI(rgb, a), CI(rgb, a * 0.35), CI(rgb, 0)], [0.0, 0.45, 1.0]))
    c.drawCircle(cx, cy, r, paint)


# ---------------------------------------------------------------- text
def tw(s, f, track=0.0):
    if not s:
        return 0.0
    if not track:
        return f.measureText(s)
    ws = f.getWidths(f.textToGlyphs(s))
    return sum(ws) + track * f.getSize() * (len(ws) - 1)


def text(c, s, x, y, f, rgb, a, align='l', track=0.0, blur=0.0):
    w = tw(s, f, track)
    if a <= 0.004 or not s:
        return w
    x0 = x - (w / 2 if align == 'c' else (w if align == 'r' else 0))
    p = PF(rgb, a, blur if blur > 0.35 else 0.0)
    if not track:
        c.drawString(s, x0, y, f, p)
    else:
        ws = f.getWidths(f.textToGlyphs(s))
        xx = x0
        for ch, wv in zip(s, ws):
            c.drawString(ch, xx, y, f, p)
            xx += wv + track * f.getSize()
    return w


def letters(c, s, x, y, f, t, t0, stagger=0.06, dur=0.5, align='c', track=0.0, rise=44, a=1.0,
            color=IVORY, colors=None, blur=10.0):
    """per-letter rise-in (brand words)"""
    ws = f.getWidths(f.textToGlyphs(s))
    w = sum(ws) + track * f.getSize() * (len(ws) - 1)
    x0 = x - (w / 2 if align == 'c' else (w if align == 'r' else 0))
    xx = x0
    for k, (ch, wv) in enumerate(zip(s, ws)):
        q = pr(t, t0 + k * stagger, dur)
        if q > 0 and a > 0.004:
            e = eo4(q)
            col = colors[k] if colors else color
            bl = (1 - e) * blur
            c.drawString(ch, xx, y + (1 - e) * rise, f, PF(col, a * min(1.0, q * 1.8), bl if bl > 0.35 else 0))
        xx += wv + track * f.getSize()
    return w


EMPH_SCALE = 1.08


def parse_line(s):
    words, emph = [], False
    for tok in s.split(' '):
        if tok == '':
            continue
        segs = []
        for j, part in enumerate(tok.split('*')):
            if j > 0:
                emph = not emph
            if part:
                segs.append((part, emph))
        words.append(segs)
    return words


def seg_font(emph, size, base='cond'):
    return font('serif_i', size * EMPH_SCALE) if emph else font(base, size)


def line_width(s, size, base='cond'):
    words = parse_line(s)
    sp = font(base, size).measureText(' ')
    return sum(sum(tw(t, seg_font(e, size, base)) for t, e in w) for w in words) + sp * (len(words) - 1)


def fit_size(lines, size, maxw, base='cond'):
    m = max(line_width(s, size, base) for s in lines)
    return size * min(1.0, maxw / m) if m > 0 else size


def headline(c, lines, t, t_in, t_out, cx, y0, size, lh, color=IVORY, ecolor=ORANGE, a=1.0, stagger=0.055,
             underline=True, base='cond', rise=36, align='c', out_dur=0.2):
    """word-by-word rise-in with blur; *emphasis* in serif italic + drawn underline"""
    k = 0
    for li, s in enumerate(lines):
        words = parse_line(s)
        sp = font(base, size).measureText(' ')
        widths = [sum(tw(t_, seg_font(e, size, base)) for t_, e in w) for w in words]
        total = sum(widths) + sp * (len(words) - 1)
        x = cx - total / 2 if align == 'c' else cx
        y = y0 + li * lh
        for w, ww in zip(words, widths):
            q = pr(t, t_in + k * stagger, 0.5)
            e = eo4(q)
            o = eio(pr(t, t_out, out_dur)) if t_out is not None else 0.0
            al = a * min(1.0, q * 1.6) * (1 - o)
            if al > 0.004:
                dy = (1 - e) * rise - o * 24
                bl = (1 - e) * 9
                xx = x
                for txt, em in w:
                    f = seg_font(em, size, base)
                    wd = text(c, txt, xx, y + dy, f, ecolor if em else color, al, blur=bl)
                    if em and underline:
                        u = eo(pr(t, t_in + k * stagger + 0.30, 0.5))
                        if u > 0:
                            uy = y + dy + size * 0.17
                            spath(c, poly([(xx + 2, uy), (xx + 2 + (wd - 4) * u, uy)]), ecolor, al * 0.9, max(2.0, size * 0.028), glow=0.6)
                    xx += wd
            x += ww + sp
            k += 1


# ---------------------------------------------------------------- icons (line art, centred at cx,cy, nominal size s)
def ic_bag(cx, cy, s):
    p = rrect_path(cx - .36 * s, cy - .16 * s, .72 * s, .58 * s, .07 * s)
    p.addArc(skia.Rect.MakeXYWH(cx - .17 * s, cy - .42 * s, .34 * s, .5 * s), 180, 180)
    return p


def ic_receipt(cx, cy, s):
    x0, x1, y0, y1 = cx - .3 * s, cx + .3 * s, cy - .42 * s, cy + .38 * s
    pts = [(x0, y0), (x1, y0), (x1, y1)]
    n = 6
    for i in range(1, n + 1):
        x = x1 - (x1 - x0) * i / n
        pts.append((x + (x1 - x0) / n / 2, y1 - .07 * s))
        pts.append((x, y1))
    p = poly(pts, close=True)
    for yy, ww in [(-.2, .36), (-.04, .36), (.12, .22)]:
        p.moveTo(cx - .18 * s, cy + yy * s)
        p.lineTo(cx - .18 * s + ww * s, cy + yy * s)
    return p


def ic_note(cx, cy, s):
    p = rrect_path(cx - .44 * s, cy - .26 * s, .88 * s, .52 * s, .06 * s)
    p.addCircle(cx, cy, .13 * s)
    p.addCircle(cx - .3 * s, cy, .025 * s)
    p.addCircle(cx + .3 * s, cy, .025 * s)
    return p


def ic_grid(cx, cy, s):
    p = skia.Path()
    q, g = .2 * s, .07 * s
    for i in range(3):
        for j in range(3):
            x = cx - 1.5 * q - g + i * (q + g)
            y = cy - 1.5 * q - g + j * (q + g)
            p.addRRect(rrect(x, y, q, q, .04 * s))
    return p


def ic_chat(cx, cy, s):
    p = skia.Path()
    x0, y0, w, h, r = cx - .4 * s, cy - .32 * s, .8 * s, .54 * s, .16 * s
    p.moveTo(x0 + r, y0)
    p.lineTo(x0 + w - r, y0)
    p.arcTo(skia.Rect.MakeXYWH(x0 + w - 2 * r, y0, 2 * r, 2 * r), -90, 90, False)
    p.lineTo(x0 + w, y0 + h - r)
    p.arcTo(skia.Rect.MakeXYWH(x0 + w - 2 * r, y0 + h - 2 * r, 2 * r, 2 * r), 0, 90, False)
    p.lineTo(x0 + .36 * s, y0 + h)
    p.lineTo(x0 + .12 * s, y0 + h + .16 * s)
    p.lineTo(x0 + .16 * s, y0 + h)
    p.arcTo(skia.Rect.MakeXYWH(x0, y0 + h - 2 * r, 2 * r, 2 * r), 90, 90, False)
    p.lineTo(x0, y0 + r)
    p.arcTo(skia.Rect.MakeXYWH(x0, y0, 2 * r, 2 * r), 180, 90, False)
    p.close()
    for dx in (-.17, 0, .17):
        p.addCircle(cx + dx * s, cy - .05 * s, .035 * s)
    return p


def ic_chart(cx, cy, s):
    p = poly([(cx - .42 * s, cy + .34 * s), (cx + .42 * s, cy + .34 * s)])
    for x, h in [(-.3, .3), (-.06, .5), (.18, .68)]:
        p.addRRect(rrect(cx + x * s, cy + .34 * s - h * s - .06 * s, .16 * s, h * s, .03 * s))
    return p


def ic_heart(cx, cy, s):
    p = skia.Path()
    p.moveTo(cx, cy + .34 * s)
    p.cubicTo(cx - .5 * s, cy + .02 * s, cx - .46 * s, cy - .42 * s, cx - .2 * s, cy - .38 * s)
    p.cubicTo(cx - .08 * s, cy - .36 * s, cx, cy - .26 * s, cx, cy - .18 * s)
    p.cubicTo(cx, cy - .26 * s, cx + .08 * s, cy - .36 * s, cx + .2 * s, cy - .38 * s)
    p.cubicTo(cx + .46 * s, cy - .42 * s, cx + .5 * s, cy + .02 * s, cx, cy + .34 * s)
    return p


def ic_comment(cx, cy, s):
    p = arc_path(cx, cy - .04 * s, .36 * s, 120, 300)
    a = math.radians(120)
    p.lineTo(cx - .34 * s, cy + .38 * s)
    p.lineTo(cx + .36 * s * math.cos(a), cy - .04 * s + .36 * s * math.sin(a))
    return p


def ic_send(cx, cy, s):
    p = poly([(cx - .38 * s, cy - .3 * s), (cx + .4 * s, cy - .02 * s), (cx - .38 * s, cy + .3 * s), (cx - .26 * s, cy - .01 * s)], close=True)
    p.moveTo(cx - .26 * s, cy - .01 * s)
    p.lineTo(cx + .12 * s, cy - .01 * s)
    return p


def ic_photo(cx, cy, s):
    p = poly([(cx - .45 * s, cy + .3 * s), (cx - .12 * s, cy - .08 * s), (cx + .06 * s, cy + .12 * s), (cx + .2 * s, cy - .02 * s), (cx + .45 * s, cy + .3 * s)])
    p.addCircle(cx + .22 * s, cy - .26 * s, .09 * s)
    return p


def ic_bulb(cx, cy, s):
    p = arc_path(cx, cy - .1 * s, .3 * s, 140, 260)
    a0, a1 = math.radians(140), math.radians(40)
    p.lineTo(cx + .12 * s, cy + .3 * s)
    p.lineTo(cx - .12 * s, cy + .3 * s)
    p.lineTo(cx + .3 * s * math.cos(a0), cy - .1 * s + .3 * s * math.sin(a0))
    p.moveTo(cx - .1 * s, cy + .42 * s)
    p.lineTo(cx + .1 * s, cy + .42 * s)
    return p


def ic_check(cx, cy, s):
    return poly([(cx - .32 * s, cy + .02 * s), (cx - .08 * s, cy + .26 * s), (cx + .36 * s, cy - .24 * s)])


def ic_person(cx, cy, s):
    p = circle_path(cx, cy - .2 * s, .2 * s)
    p.addArc(skia.Rect.MakeXYWH(cx - .38 * s, cy + .08 * s, .76 * s, .7 * s), 200, 140)
    return p


def ic_spark(cx, cy, s):
    p = skia.Path()
    p.moveTo(cx, cy - .42 * s)
    p.quadTo(cx + .06 * s, cy - .06 * s, cx + .42 * s, cy)
    p.quadTo(cx + .06 * s, cy + .06 * s, cx, cy + .42 * s)
    p.quadTo(cx - .06 * s, cy + .06 * s, cx - .42 * s, cy)
    p.quadTo(cx - .06 * s, cy - .06 * s, cx, cy - .42 * s)
    return p


ICONS = {'bag': ic_bag, 'receipt': ic_receipt, 'note': ic_note, 'grid': ic_grid, 'chat': ic_chat, 'chart': ic_chart,
         'heart': ic_heart, 'comment': ic_comment, 'send': ic_send, 'photo': ic_photo, 'bulb': ic_bulb,
         'check': ic_check, 'person': ic_person, 'spark': ic_spark}


def node(c, x, y, a=1.0, s=1.0, ring=True, glow=0.6):
    if a <= 0.004:
        return
    if glow:
        glow_blob(c, x, y, 26 * s, ORANGE, 0.45 * a * glow)
    c.drawCircle(x, y, 6.5 * s, PF(ORANGE, a))
    if ring:
        c.drawCircle(x, y, 13.5 * s, PS(IVORY, 0.55 * a, 1.6 * s))
