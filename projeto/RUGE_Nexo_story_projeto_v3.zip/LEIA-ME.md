# RUGE + Nexo · teaser 30 s · projeto editável (v1)

Vídeo 1080×1920, 30 fps, 30 s, sem narração. Tudo é desenhado por código (Python + skia + ffmpeg). A trilha e os efeitos são sintetizados, sem amostras de terceiros.

## Arquivos
- `teaser.py`: cenas, textos e tempos. Os tempos estão no dicionário `S`, no topo. As perguntas estão em `heads` e os textos do painel em `FEATS`.
- `gfx.py`: paleta (`IVORY`, `ORANGE`…), fontes, traços e ícones.
- `sound.py`: trilha (100 BPM) e efeitos. Gera `mix.wav`, `musica_stem.wav` e `sfx_stem.wav`.
- `fonts/`: Barlow, Barlow Condensed e Instrument Serif (licença SIL OFL, arquivos de licença incluídos).

## Como renderizar
```
pip install skia-python opencv-python-headless numpy scipy
python3 teaser.py 0 900      # quadros em out/
python3 sound.py             # áudio
ffmpeg -framerate 30 -i out/%04d.jpg -i mix.wav -map 0:v -map 1:a -c:v libx264 -crf 17 -pix_fmt yuv420p -c:a aac -b:a 256k -shortest teaser.mp4
```

## Roteiro
| Tempo | Cena |
|---|---|
| 0,0 | Postou… e ninguém viu? (linha de batimento que fica reta) |
| 2,4 | Sem tempo… e sem ideia do que postar? (relógio acelerando) |
| 4,8 | Paga alguém… e não vê o que foi feito? (pagamento e relatório vazio) |
| 7,2 | Pedidos, notas, caixa… tudo espalhado? |
| 9,6 | E se tudo estivesse conectado? (as peças se ligam num nó central) |
| 12,0 | RUGE + NEXO: "A RUGE cria. O Nexo acompanha." |
| 15,0 | Um painel só seu |
| 17,4 | Escala de posts pronta |
| 19,8 | Seus números, sem complicação |
| 22,2 | Assunto sério? Gente de verdade assume (conversa passa para a equipe) |
| 25,2 | Em breve: pedidos, notas e caixa |
| 27,6 | Tela final: Dando voz à sua marca + @ruge.marketing |

## Pendências
- O nome RUGE está digitado com a fonte da marca. Trocar pela logo oficial (arquivo 03) quando ela estiver disponível.
- O Nexo e o painel ainda estão em construção; as telas do celular são ilustrativas (números de exemplo).
