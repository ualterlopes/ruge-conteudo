"""RUGE + Nexo — story 15 s, 1080x1920, 30 fps (sem narração).
Uso:  python3 story.py A B          -> quadros A..B-1 em sout/
      python3 story.py test t1 t2.. -> JPGs de teste em stest/
Reaproveita fundo, poeira, rede, cantos e cartão final do teaser.py.
"""
import os, sys, math
import numpy as np
import cv2
import skia
import teaser as T
from gfx import *

DUR = 16.5
N = int(round(DUR * FPS))
CH_IN = [0.6, 1.2, 1.8, 2.4, 3.0, 3.6]       # tarefas entram (batidas de 0,6 s)
AWAKE = 4.8                                    # o Nexo acorda
RES = [5.7, 6.3, 6.9, 7.5, 8.1, 8.7]          # tarefas resolvidas
FIN = 13.0                                     # tela 45% + EM BREVE
END = 10.8                                     # cartão final (iris a partir do notebook)
IRIS = 0.6
T.S['end'] = END                               # corners()/scene_end() do teaser leem isto
CX, HY, R = 540, 715, 72                       # centro do corpo, centro da cabeça, raio
NODE = (540, 948)                              # nó Nexo na tampa do notebook
CHW, CHH = 330, 84
CHIPS = [('Postar no Instagram', 'photo', 250, 470), ('Emitir nota fiscal', 'receipt', 830, 560),
         ('Pedido do iFood', 'bag', 250, 650), ('Fechar o caixa', 'chart', 830, 740),
         ('Responder clientes', 'chat', 250, 830), ('Ter ideia de post', 'bulb', 830, 920)]


def stress_k(t):
    return eo(pr(t, 0.5, 3.0))


def calm_k(t):
    return eio(pr(t, 5.3, 1.1))


# ---------------------------------------------------------------- personagem
def teardrop(x, y):
    p = skia.Path()
    p.moveTo(x, y - 14)
    p.cubicTo(x + 10, y - 2, x + 9, y + 8, x, y + 8)
    p.cubicTo(x - 9, y + 8, x - 10, y - 2, x, y - 14)
    return p


def person(c, t):
    p = eo(pr(t, 0.0, 1.2))
    if p <= 0:
        return
    s, m = stress_k(t), calm_k(t)
    tr = s * (1 - m)
    ox = math.sin(t * 41) * 1.5 * tr
    oy = math.sin(t * 33 + 1) * 1.0 * tr + math.sin(t * 2.2) * 1.4 * (0.4 + m)   # respira
    cx, hy = CX, HY
    # --- mesa
    spath(c, poly([(150, 1012), (930, 1012)]), IVORY, 0.55, 2.4, p=p)
    spath(c, poly([(210, 1030), (870, 1030)]), IVORY, 0.18, 1.4, p=p)
    spath(c, poly([(300, 1048), (780, 1048)]), IVORY, 0.09, 1.2, p=p)
    c.save()
    c.translate(ox, oy)
    # --- tronco (por trás do notebook)
    for sg in (-1, 1):
        body = skia.Path()
        body.moveTo(cx + sg * 26, hy + 94)
        body.quadTo(cx + sg * 80, hy + 100, cx + sg * 115, hy + 152)
        body.lineTo(cx + sg * 118, 1012 - oy)
        spath(c, body, IVORY, 0.85, 3, p=p)
        spath(c, poly([(cx + sg * 48, hy + 103), (cx + sg * 88, 882)]), ORANGE, 0.85, 3, p=p)   # alça do avental
        neck = poly([(cx + sg * 26, hy + R - 8), (cx + sg * 26, hy + 94)])
        spath(c, neck, IVORY, 0.85, 3, p=p)
    spath(c, poly([(cx - 26, hy + 94), (cx, hy + 130), (cx + 26, hy + 94)]), IVORY, 0.5, 2.4, p=p)
    # --- cabeça
    c.drawCircle(cx, hy, R, PF(BG_C, 0.92 * p))
    spath(c, circle_path(cx, hy, R), IVORY, 0.92, 3.2, p=p)
    for sg in (-1, 1):
        spath(c, arc_path(cx + sg * R, hy + 10, 12, 90 if sg < 0 else 270, 180), IVORY, 0.8, 2.6, p=p)
    # boné laranja
    spath(c, arc_path(cx, hy, R + 5, 205, 130), ORANGE, 0.95, 4, p=p, glow=0.5)
    br = skia.Path()
    br.moveTo(cx - R - 12, hy - 30)
    br.quadTo(cx, hy - 12, cx + R + 12, hy - 30)
    spath(c, br, ORANGE, 0.95, 4, p=p, glow=0.5)
    fa = eo(cl((p - 0.7) / 0.3))
    if fa > 0:
        blink = 0.12 > (t % 3.1)
        er = lerp(5.8, 4.4, m) * fa
        for sg in (-1, 1):
            ex = cx + sg * 27
            if blink:
                c.drawLine(ex - 6, hy + 10, ex + 6, hy + 10, PS(IVORY, 0.95 * fa, 2.6))
            else:
                c.drawCircle(ex + math.sin(t * 5) * 1.2 * tr, hy + 9, er, PF(IVORY, 0.95 * fa))
            # sobrancelhas: preocupadas (lado interno alto) -> relaxadas
            inner = lerp(hy - 24, hy - 15, m)
            outer = lerp(hy - 6, hy - 17, m)
            spath(c, poly([(cx + sg * 14, inner), (cx + sg * 46, outer)]), IVORY, 0.9 * fa, 3)
        nz = skia.Path()
        nz.moveTo(cx + 2, hy + 14)
        nz.quadTo(cx - 5, hy + 28, cx + 3, hy + 29)
        spath(c, nz, IVORY, 0.55 * fa, 2.4)
        mo = skia.Path()
        mo.moveTo(cx - 24, hy + 47)
        mo.cubicTo(cx - 10, hy + 47 + lerp(9, 17, m), cx + 10, hy + 47 + lerp(-9, 17, m), cx + 24, hy + 47 + lerp(0, -2, m))
        spath(c, mo, IVORY, 0.95 * fa, 3)
        if tr > 0.02:   # suor + rabisco de estresse
            dy = (t * 70) % 70
            spath(c, teardrop(cx + 98, hy - 6 + dy * 0.6), IVORY, 0.8 * tr * (1 - dy / 90), 2.4)
            for ang in (-128, -90, -52):
                a = math.radians(ang)
                jit = math.sin(t * 24 + ang) * 4
                spath(c, poly([(cx + (R + 70 + jit) * math.cos(a), hy + (R + 70 + jit) * math.sin(a)),
                               (cx + (R + 100 + jit) * math.cos(a), hy + (R + 100 + jit) * math.sin(a))]), IVORY, 0.7 * tr, 2.6)
    c.restore()
    # --- notebook (visto por trás) com o nó do Nexo
    lid = rrect(CX - 90, 884, 180, 128, 14)
    c.drawRRect(lid, PF(BG_C, 0.98 * p))
    spath(c, rrect_path(CX - 90, 884, 180, 128, 14), IVORY, 0.9, 3, p=p)
    spath(c, poly([(CX - 112, 1013), (CX + 112, 1013)]), IVORY, 0.9, 4, p=p)
    for sg in (-1, 1):
        c.drawCircle(CX + sg * 112, 996 + oy * 0.5, 15, PF(BG_C, 0.98 * p))
        spath(c, circle_path(CX + sg * 112, 996 + oy * 0.5, 15), IVORY, 0.75, 2.6, p=p)
    aw = eob(pr(t, AWAKE, 0.55))
    base = 0.28 * eo(pr(t, 0.9, 0.6))
    glow = max(base, aw)
    node(c, NODE[0], NODE[1], a=max(glow, 0.0001), s=max(0.6 + 0.4 * aw, 0.01), glow=0.4 + 1.0 * aw)
    for k in range(3):   # ondas saindo do notebook quando acorda
        q = pr(t, AWAKE + 0.1 + k * 0.28, 0.9)
        if 0 < q < 1:
            c.drawCircle(NODE[0], NODE[1], 20 + 330 * eo(q), PS(ORANGE, 0.55 * (1 - q), 2.2))
    # --- caneca (calma)
    mq = eo(pr(t, 6.3, 0.6))
    if mq > 0:
        mx = CX - 232
        spath(c, rrect_path(mx - 24, 962, 48, 50, 8), IVORY, 0.85, 2.8, p=mq)
        spath(c, arc_path(mx - 24, 986, 14, 90, 180), IVORY, 0.85, 2.8, p=mq)
        for k in range(3):
            st = skia.Path()
            x0 = mx - 12 + k * 12
            st.moveTo(x0, 948)
            for j in range(1, 8):
                st.lineTo(x0 + math.sin(t * 3 + k * 1.7 + j * 0.9) * 6, 948 - j * 9)
            sa = 0.5 * eo(pr(t, 6.8 + k * 0.1, 0.6)) * (0.6 + 0.4 * math.sin(t * 2 + k))
            spath(c, st, IVORY, sa, 2.0)


# ---------------------------------------------------------------- tarefas
def count_at(t):
    n = sum(1 for v in CH_IN if t >= v + 0.2) - sum(1 for v in RES if t >= v + 0.55)
    return n


def chip_conn(k):
    name, ic, x, y = CHIPS[k]
    sg = -1 if x < CX else 1
    end = (x - sg * CHW / 2, y)
    c1 = (CX + sg * 40, NODE[1] - 140)
    c2 = (end[0] - sg * 120, y + (60 if y < NODE[1] - 150 else 0))
    return cubic(NODE, c1, c2, end)


def draw_chip(c, k, t):
    name, ic, x, y = CHIPS[k]
    q = eob(pr(t, CH_IN[k], 0.45))
    if q <= 0:
        return
    rp = eio(pr(t, RES[k], 0.45))
    done = eo(pr(t, RES[k] + 0.35, 0.35))
    dim = 0.5 * eio(pr(t, AWAKE, 0.4)) * (1 - eo(pr(t, RES[k], 0.3)))
    al = min(1.0, q * 1.6) * (1 - dim)
    tr = stress_k(t) * (1 - calm_k(t))
    jx = math.sin(t * 17 + k * 2.1) * 3.2 * tr * (1 - done)
    jy = math.sin(t * 13 + k) * 2.0 * tr * (1 - done) + (1 - eo(pr(t, CH_IN[k], 0.5))) * -26
    sc = max(q, 0.01) * (1 + 0.02 * done)
    # conexão do Nexo
    if rp > 0:
        pth = chip_conn(k)
        spath(c, pth, ORANGE, 0.9 * (1 - 0.7 * done), 2.4, p=rp, glow=0.9)
        (dx, dy), _ = point_at(pth, rp)
        if rp < 0.999:
            c.drawCircle(dx, dy, 6, PF(ORANGE, 1.0))
    c.save()
    c.translate(x + jx, y + jy)
    c.scale(sc, sc)
    w, h = CHW, CHH
    glowk = max(rp, done)
    if glowk > 0:
        glow_blob(c, 0, 0, 150, ORANGE, 0.14 * glowk * al)
    c.drawRRect(rrect(-w / 2, -h / 2, w, h, h / 2), PF(BG_C, 0.97 * al))
    spath(c, rrect_path(-w / 2, -h / 2, w, h, h / 2), mixc(IVORY, ORANGE, glowk), (0.62 + 0.3 * glowk) * al, 2.2)
    # ícone -> check
    ix = -w / 2 + 50
    if done < 1:
        spath(c, ICONS[ic](ix, 0, 40), IVORY, 0.9 * al * (1 - done), 2.4)
    if done > 0:
        spath(c, circle_path(ix, 0, 25), ORANGE, 0.9 * al, 2.4, p=done)
        spath(c, ic_check(ix, 0, 30), ORANGE, 1.0 * al, 3.4, p=eo(cl((done - 0.3) / 0.7)))
    f = font('sansm', 26)
    tx = -w / 2 + 92
    text(c, name, tx, 9, f, IVORY, (0.95 - 0.4 * done) * al)
    if done > 0:
        spath(c, poly([(tx - 2, 1), (tx + tw(name, f) + 2, 1)]), ORANGE, 0.9 * al, 2.4, p=done)
    # alerta
    if done < 1 and t < RES[k] + 0.4:
        ba = al * (1 - eo(pr(t, RES[k], 0.2))) * min(1, q)
        pulse = 1 + 0.12 * math.sin(t * 9 + k)
        bx, by = w / 2 - 22, -h / 2 + 4
        c.drawCircle(bx, by, 15 * pulse, PF(ORANGE, 0.95 * ba))
        text(c, '!', bx, by + 8, font('sanssb', 22), BG_E, ba, align='c')
    c.restore()


def counter(c, t):
    n = count_at(t)
    ev = [v + 0.2 for v in CH_IN] + [v + 0.55 for v in RES]
    past = [e for e in ev if e <= t]
    if not past:
        return
    tc = max(past)
    nprev = count_at(tc - 0.001)
    q = eo(pr(t, tc, 0.32))
    vis = eo(pr(t, CH_IN[0] + 0.1, 0.4))
    nf = lerp(nprev, n, q)
    ring = nf / 6.0
    zero = n == 0
    col = mixc(IVORY, ORANGE, min(1.0, nf / 4.0)) if not zero else ORANGE
    cx, cy = 540, 540
    c.drawCircle(cx, cy, 92, PS(IVORY, 0.12 * vis, 2))
    spath(c, arc_path(cx, cy, 92, -90, max(0.01, 360 * ring)), col, 0.95 * vis, 4.5, glow=0.7)
    f = font('cond', 118)
    if zero:
        gq = eo(pr(t, tc + 0.1, 0.45))
        spath(c, circle_path(cx, cy, 40), ORANGE, 0.0, 1)
        spath(c, ic_check(cx, cy, 86), ORANGE, 1.0 * vis, 6, p=gq, glow=0.8)
    else:
        if q < 1 and nprev != n:
            text(c, str(nprev), cx, cy + 42 - 26 * q, f, col, (1 - q) * vis, align='c', blur=3 * q)
            text(c, str(n), cx, cy + 42 + 26 * (1 - q), f, col, q * vis, align='c', blur=3 * (1 - q))
        else:
            text(c, str(n), cx, cy + 42, f, col, vis, align='c')
    lab = 'TUDO EM DIA' if zero else ('PENDENTES' if n > 0 else '')
    lc = ORANGE if zero else IVORY
    text(c, lab, cx, 426, font('condm', 25), lc, (0.9 if zero else 0.6) * vis, align='c', track=0.3)


def construction(c, t):
    """linhas técnicas de fundo ao redor da figura"""
    a = eo(pr(t, 0.2, 1.0))
    cx, cy = CX, 840
    c.drawCircle(cx, cy, 392, PS(IVORY, 0.10 * a, 1.4, dash=(3, 11), phase=-t * 9))
    c.drawCircle(cx, cy, 300, PS(IVORY, 0.07 * a, 1.2, dash=(14, 10), phase=t * 6))
    for sg in (-1, 1):
        for yy in (cy - 392, cy + 392):
            pass
        c.drawLine(cx + sg * 392 - 10, cy, cx + sg * 392 + 10, cy, PS(IVORY, 0.25 * a, 1.6))
    c.drawLine(cx, cy - 392 - 10, cx, cy - 392 + 10, PS(IVORY, 0.25 * a, 1.6))


# ---------------------------------------------------------------- final
def scene_end2(c, t):
    lt = t - END
    glow_blob(c, 540, 900, 640, ORANGE, 0.08 * eo(pr(lt, 0.2, 0.6)))
    letters(c, 'RUGE', 540, 770, font('cond', 160), lt, 0.2, stagger=0.05, dur=0.5, track=0.06, rise=44)
    sq = eo(pr(lt, 0.45, 0.4))
    text(c, 'MARKETING E SOLUÇÕES DIGITAIS', 540, 818 + (1 - sq) * 10, font('condm', 25), IVORY, 0.62 * sq, align='c', track=0.3)
    lq = eo(pr(lt, 0.5, 0.3))
    spath(c, poly([(540, 848), (540, 848 + 64 * lq)]), IVORY, 0.55, 1.6)
    nq = eob(pr(lt, 0.6, 0.35))
    if nq > 0:
        node(c, 540, 880, a=min(1, nq * 1.6), s=max(nq, 0.01), glow=0.8)
    letters(c, 'NEXO', 540, 1010, font('cond', 120), lt, 0.65, stagger=0.05, dur=0.5, track=0.18, rise=40, colors=T.NEXO_COLORS)
    headline(c, ['Seu *assistente* de posts,', 'notas e caixa.'], t, END + 1.0, FIN - 0.15, 540, 1092, 52, 58, base='sans', stagger=0.06)


def scene_final(c, t):
    lt = t - FIN
    glow_blob(c, 540, 900, 560, ORANGE, 0.10 * eo(pr(lt, 0.0, 0.6)))
    letters(c, 'NEXO', 540, 636, font('cond', 60), lt, 0.05, stagger=0.05, dur=0.45, track=0.2, rise=26, colors=T.NEXO_COLORS)
    k = eo(pr(lt, 0.2, 1.05))
    v = int(round(45 * k))
    qa = eo(pr(lt, 0.15, 0.3))
    if qa > 0:
        f = font('cond', 280)
        text(c, f'{v}%', 540, 880, f, ORANGE, qa, align='c', blur=0)
    # barra de progresso
    bx, by, bw, bh = 190, 928, 700, 20
    ba = eo(pr(lt, 0.2, 0.4))
    if ba > 0:
        c.drawRRect(rrect(bx, by, bw, bh, bh / 2), PF(CARD, 0.9 * ba))
        spath(c, rrect_path(bx, by, bw, bh, bh / 2), IVORY, 0.5 * ba, 1.8)
        fw = bw * 0.45 * k
        if fw > 2:
            c.save()
            c.clipRect(skia.Rect.MakeXYWH(bx, by - 4, fw, bh + 8), skia.ClipOp.kIntersect, True)
            c.drawRRect(rrect(bx, by, bw, bh, bh / 2), PF(ORANGE, 0.97 * ba))
            c.restore()
            glow_blob(c, bx + fw, by + bh / 2, 34, ORANGE, 0.6 * ba)
            c.drawCircle(bx + fw, by + bh / 2, 9, PF(IVORY, ba))
        for j in range(5):
            xx = bx + bw * j / 4
            c.drawLine(xx, by + bh + 10, xx, by + bh + (24 if j % 2 == 0 else 18), PS(IVORY, 0.35 * ba, 1.6))
    # EM BREVE
    cols = [IVORY, IVORY, IVORY, ORANGE, ORANGE, ORANGE, ORANGE, ORANGE]
    letters(c, 'EM BREVE', 540, 1158, font('cond', 200), lt, 0.95, stagger=0.055, dur=0.5, track=0.05, rise=70, colors=cols, blur=16)
    br = eo(pr(lt, 1.5, 0.5))
    if br > 0:
        pulse = 0.85 + 0.15 * math.sin(t * 5)
        glow_blob(c, 540, 1100, 420, ORANGE, 0.07 * br * pulse)
    q = eo(pr(lt, 1.55, 0.45))
    text(c, 'EXCLUSIVO DA RUGE', 540, 1214 + (1 - q) * 8, font('condm', 30), IVORY, 0.75 * q, align='c', track=0.34)
    f = font('sansm', 30)
    s_ = 'Chama no direct  ·  @ruge.marketing'
    w = tw(s_, f) + 70
    pq = eo(pr(lt, 1.85, 0.5))
    if pq > 0:
        spath(c, rrect_path(540 - w / 2, 1252, w, 72, 36), ORANGE, 0.9, 2, p=pq, glow=0.5)
        tq = eo(pr(lt, 2.0, 0.4))
        text(c, s_, 540, 1299 + (1 - tq) * 8, f, IVORY, tq, align='c')


def scene_end_all(c, t):
    fa = 1 - eio(pr(t, FIN - 0.28, 0.28))
    if fa > 0.004:
        pnt = skia.Paint()
        pnt.setAlphaf(fa)
        c.saveLayer(None, pnt)
        scene_end2(c, t)
        c.restore()
    if t >= FIN - 0.02:
        scene_final(c, t)


# ---------------------------------------------------------------- quadro
def render(t):
    surf = skia.Surface(W, H)
    c = surf.getCanvas()
    c.drawImage(T.BG, 0, 0)
    T.draw_dust(c, t)
    T.draw_net(c, t)
    construction(c, t)
    for k in range(6):
        draw_chip(c, k, t)
    person(c, t)
    counter(c, t)
    # rótulo FIG
    if t < 5.0:
        T.fig_label(c, t, 0.3, 1, 'O DIA A DIA', a=1 - eio(pr(t, 4.6, 0.25)))
    elif t < END + 0.2:
        T.fig_label(c, t, 5.1, 2, 'COM O NEXO', a=1 - eio(pr(t, END - 0.3, 0.25)))
    T.kicker(c, t, 'JÁ PASSOU POR ISSO?', 0.1, 4.45)
    T.kicker(c, t, 'NEXO EM AÇÃO', 5.6, 10.25)
    heads = [(0.25, 4.75, ['Tanta coisa pra fazer…', 'e *sozinho*?']),
             (4.95, 7.55, ['Já imaginou ter um', 'sistema que te *ajudasse*?']),
             (7.75, 10.45, ['O *Nexo* cuida', 'do resto.'])]
    for t0, t1, lines in heads:
        if t0 - 0.05 <= t <= t1 + 0.35:
            size = fit_size(lines, 90, 860)
            T.headline(c, lines, t, t0 + 0.12, t1 - 0.2, 540, 1290, size, size * 1.06)
    # cartão final (iris a partir do notebook)
    if t >= END:
        r = 1400 * eio(pr(t, END, IRIS))
        c.save()
        c.clipPath(circle_path(NODE[0], NODE[1], max(r, 0.5)), skia.ClipOp.kIntersect, True)
        c.drawImage(T.BG, 0, 0)
        T.draw_dust(c, t)
        T.draw_net(c, t)
        scene_end_all(c, t)
        c.restore()
        if r < 1390:
            spath(c, circle_path(NODE[0], NODE[1], max(r, 0.5)), ORANGE, 0.95, 3, glow=1.0)
            spath(c, circle_path(NODE[0], NODE[1], max(r * 0.93, 0.5)), IVORY, 0.3, 1.2)
    T.corners(c, t)
    return surf.makeImageSnapshot().toarray()


if __name__ == '__main__':
    os.chdir(T.HERE)
    if sys.argv[1] == 'test':
        os.makedirs('stest', exist_ok=True)
        for s in sys.argv[2:]:
            t = float(s)
            i = int(round(t * FPS))
            cv2.imwrite(f'stest/t{t:05.2f}.jpg', T.finish(render(t), i), [cv2.IMWRITE_JPEG_QUALITY, 92])
        print('ok')
    else:
        a, b = int(sys.argv[1]), int(sys.argv[2])
        os.makedirs('sout', exist_ok=True)
        for i in range(a, min(b, N)):
            cv2.imwrite(f'sout/{i:04d}.jpg', T.finish(render(i / FPS), i), [cv2.IMWRITE_JPEG_QUALITY, 95])
        print('done', a, b)
