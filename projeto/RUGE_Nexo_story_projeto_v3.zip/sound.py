"""Trilha e efeitos do teaser RUGE + Nexo — 100% sintetizados (sem amostras, sem direitos de terceiros).
Gera: musica_stem.wav, sfx_stem.wav, mix.wav (48 kHz, estéreo).  Tempos vêm de teaser.py.
"""
import os, sys, json, subprocess, math
import numpy as np
from scipy import signal
from scipy.io import wavfile

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from teaser import S, CONN_T, ECG, F4T, DUR       # noqa: E402
from gfx import point_at, contour_lengths          # noqa: E402

SR = 48000
N = int(SR * DUR)
BEAT = 0.6
rng = np.random.default_rng(2026)


def T(n):
    return np.arange(n) / SR


def mtof(m):
    return 440.0 * 2 ** ((m - 69) / 12.0)


def lp(x, fc, o=2):
    return signal.sosfilt(signal.butter(o, min(fc, SR * 0.45), 'low', fs=SR, output='sos'), x)


def hp(x, fc, o=2):
    return signal.sosfilt(signal.butter(o, fc, 'high', fs=SR, output='sos'), x)


def bp(x, lo, hi, o=2):
    return signal.sosfilt(signal.butter(o, [lo, min(hi, SR * 0.45)], 'band', fs=SR, output='sos'), x)


def env_ad(n, a, d):
    t = T(n)
    return np.minimum(1.0, t / max(a, 1e-4)) * np.exp(-t / max(d, 1e-4))


def env_asr(n, a, r):
    e = np.ones(n)
    ka, kr = int(a * SR), int(r * SR)
    if ka > 0:
        e[:ka] = np.linspace(0, 1, ka) ** 1.5
    if kr > 0:
        e[-kr:] *= np.linspace(1, 0, kr) ** 1.5
    return e


def nz(d):
    return rng.standard_normal(int(d * SR))


class Bus:
    def __init__(self):
        self.x = np.zeros((N, 2))

    def add(self, t0, s, g=1.0, pan=0.0):
        i = int(round(t0 * SR))
        if i >= N:
            return
        if s.ndim == 1:
            a = (pan + 1) * np.pi / 4
            s = np.stack([s * np.cos(a), s * np.sin(a)], 1) * math.sqrt(2)
        if i < 0:
            s, i = s[-i:], 0
        n = min(len(s), N - i)
        self.x[i:i + n] += s[:n] * g


def reverb(x, decay=1.6, mix=0.22, pre=0.012, hi=6500):
    n = int(decay * 1.4 * SR)
    t = T(n)
    out = np.zeros_like(x)
    for ch in range(2):
        ir = rng.standard_normal(n) * np.exp(-t * 6.9 / decay)
        ir = lp(ir, hi)
        ir[: int(pre * SR)] = 0
        ir /= np.sqrt((ir ** 2).sum())
        out[:, ch] = signal.fftconvolve(x[:, ch], ir)[: len(x)]
    return x + mix * out


# ============================================================ instruments
def saw(f, n, phase=0.0):
    return signal.sawtooth(2 * np.pi * f * T(n) + phase)


def pad_chord(notes, d, cutoff, det=0.08, att=0.35, rel=0.45):
    n = int(d * SR)
    s = np.zeros(n)
    for m in notes:
        f = mtof(m)
        for c in (-det, 0, det):
            s += saw(f * 2 ** (c / 12), n, rng.uniform(0, 6.28))
    s = lp(lp(s, cutoff), cutoff * 1.4) / (len(notes) * 3)
    s *= env_asr(n, att, rel)
    return s


def pluck(f, d=0.5, bright=1.0):
    n = int(d * SR)
    t = T(n)
    s = np.zeros(n)
    for h, a in ((1, 1.0), (2, 0.5), (3, 0.28), (4, 0.16), (5, 0.1), (6, 0.06)):
        s += a * np.sin(2 * np.pi * f * h * t) * np.exp(-t * (5 + 7 * h / bright))
    s *= np.minimum(1, t / 0.002)
    return s / 1.8


def bell(f, d=1.6):
    n = int(d * SR)
    t = T(n)
    s = sum(a * np.sin(2 * np.pi * f * r * t) * np.exp(-t * k) for r, a, k in ((1, 1, 2.2), (2.01, .45, 3.5), (3.0, .25, 5), (4.2, .12, 7)))
    return s * np.minimum(1, t / 0.003) / 1.7


def kick(g=1.0, f0=150, f1=44, d=0.42):
    n = int(d * SR)
    t = T(n)
    f = f1 + (f0 - f1) * np.exp(-t * 28)
    s = np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-t * 8.5)
    click = hp(rng.standard_normal(n), 3000) * np.exp(-t * 400) * 0.18
    return np.tanh((s + click) * 1.3) * g


def clap(g=1.0):
    d = 0.32
    n = int(d * SR)
    t = T(n)
    x = bp(rng.standard_normal(n), 900, 3600)
    e = np.zeros(n)
    for k, o in enumerate((0, 0.011, 0.022)):
        i = int(o * SR)
        e[i:] += np.exp(-(t[: n - i]) * (160 if k < 2 else 26)) * (0.8 if k < 2 else 1.0)
    return x * e * 0.5 * g


def hat(open_=False, g=1.0):
    d = 0.22 if open_ else 0.05
    n = int(d * SR)
    t = T(n)
    return hp(rng.standard_normal(n), 7500) * np.exp(-t * (14 if open_ else 95)) * 0.35 * g


def bass(f, d, g=1.0):
    n = int(d * SR)
    t = T(n)
    s = np.sin(2 * np.pi * f * t) + 0.25 * np.sin(2 * np.pi * 2 * f * t)
    s = np.tanh(s * 1.4) * env_asr(n, 0.008, 0.05)
    return lp(s, 900) * g


def tick(f=2400, g=1.0, d=0.04):
    n = int(d * SR)
    t = T(n)
    return (np.sin(2 * np.pi * f * t) * np.exp(-t * 110) + bp(rng.standard_normal(n), 3000, 9000) * np.exp(-t * 160) * 0.4) * g


# ============================================================ SFX (foley sintetizado)
def pop(f0=420, f1=980, d=0.09):
    n = int(d * SR)
    t = T(n)
    f = f0 + (f1 - f0) * (t / d) ** 0.5
    return np.sin(2 * np.pi * np.cumsum(f) / SR) * np.minimum(1, t / 0.003) * np.exp(-t * 38)


def chime(f=880, d=1.0):
    n = int(d * SR)
    t = T(n)
    s = sum(a * np.sin(2 * np.pi * f * m * t) * np.exp(-t * k) for m, a, k in ((1, 1, 4), (1.5, .5, 5), (2, .25, 7)))
    return s * np.minimum(1, t / 0.004) / 1.6


def glass(base=1568):
    out = np.zeros(int(1.2 * SR))
    for k, f in enumerate((base, base * 4 / 3, base * 5 / 3)):
        c = chime(f, 1.0) * (0.8 - 0.2 * k)
        i = int(0.035 * k * SR)
        out[i:i + len(c)] += c[: len(out) - i]
    return out


def swell(root=392, d=0.9):
    n = int(d * SR)
    t = T(n)
    e = np.minimum(1, t / 0.2) * np.exp(-np.maximum(t - 0.2, 0) * 4.5)
    return sum(a * np.sin(2 * np.pi * root * m * t) for m, a in ((1, 1), (1.25, .6), (1.5, .5), (2, .25))) * e / 2.3


def scratch(d=0.6, lo=2200, hi=7000, rate=9):
    n = int(d * SR)
    t = T(n)
    mod = 0.45 + 0.55 * np.abs(np.sin(2 * np.pi * rate * t + rng.uniform(0, 3)))
    hump = np.sin(np.pi * np.minimum(t / d, 1)) ** 0.6
    return bp(rng.standard_normal(n), lo, hi) * mod * hump


def marker(d=0.45):
    n = int(d * SR)
    t = T(n)
    mod = 0.6 + 0.4 * np.sin(2 * np.pi * 5 * t)
    hump = np.sin(np.pi * np.minimum(t / d, 1)) ** 0.8
    body = bp(rng.standard_normal(n), 700, 3800) * mod * hump
    return body + 0.3 * bp(rng.standard_normal(n), 3800, 8000) * hump


def coin():
    d = 1.1
    n = int(d * SR)
    t = T(n)
    out = np.zeros(n)
    for t0, g in ((0, 1.0), (0.17, 0.45), (0.29, 0.25), (0.37, 0.14)):
        i = int(t0 * SR)
        tt = t[: n - i]
        s = sum(a * np.sin(2 * np.pi * 3100 * r * tt) * np.exp(-tt * k) for r, a, k in ((1, 1, 9), (2.76, .5, 14), (5.4, .3, 20), (8.9, .15, 28)))
        out[i:] += s * g * np.minimum(1, tt / 0.001)
    return out / 2


def rip(d=0.45):
    n = int(d * SR)
    out = np.zeros(n)
    k = 0.0
    while k < d - 0.01:
        gl = int(rng.uniform(0.002, 0.008) * SR)
        i = int(k * SR)
        g = bp(rng.standard_normal(gl), 1200, 9500) * np.hanning(gl)
        out[i:i + gl] += g[: max(0, min(gl, n - i))] * rng.uniform(0.4, 1.0)
        k += rng.uniform(0.004, 0.02) * (1 - 0.6 * k / d)
    out += lp(rng.standard_normal(n), 500) * np.hanning(n) * 0.25
    return out


def flick(d=0.18):
    n = int(d * SR)
    t = T(n)
    s = bp(rng.standard_normal(n), 900, 7500) * (0.5 + 0.5 * np.abs(np.sin(2 * np.pi * 34 * t))) * np.sin(np.pi * t / d) ** 2
    snap = bp(rng.standard_normal(int(0.012 * SR)), 1500, 6000) * np.hanning(int(0.012 * SR))
    s[-len(snap):] += snap * 0.8
    return s


def beep(f=1000, d=0.11):
    n = int(d * SR)
    return np.sin(2 * np.pi * f * T(n)) * env_asr(n, 0.004, 0.03)


def boom(d=1.6):
    n = int(d * SR)
    t = T(n)
    f = 30 + 40 * np.exp(-t * 6)
    s = np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-t * 2.2)
    s += lp(rng.standard_normal(n), 300) * np.exp(-t * 9) * 0.5
    return np.tanh(s * 1.5)


def growl(d=1.0):
    n = int(d * SR)
    t = T(n)
    am = 0.55 + 0.45 * np.sin(2 * np.pi * (28 + 6 * np.sin(2 * np.pi * 1.3 * t)) * t)
    s = lp(rng.standard_normal(n), 420) * am * 1.6 + 0.6 * np.sin(2 * np.pi * np.cumsum(70 - 22 * t / d) / SR) * am
    return np.tanh(s) * np.minimum(1, t / 0.05) * np.exp(-t * 2.8)


def riser(d):
    n = int(d * SR)
    t = T(n)
    x = rng.standard_normal(n)
    out = np.zeros(n)
    ch = 1024
    for s in range(0, n, ch):
        u = s / n
        c = 400 * (9000 / 400) ** (u ** 1.4)
        out[s:s + ch] = bp(x[s:s + ch], max(c * 0.7, 60), min(c * 1.5, 20000))
    tone = np.sin(2 * np.pi * np.cumsum(220 * 2 ** (2 * (t / d) ** 2)) / SR) * 0.25
    return (out * 0.8 + tone) * (t / d) ** 2


# ============================================================ music
def music():
    mb = Bus()      # dry
    pads = Bus()    # goes through reverb
    drums = Bus()

    # ---- A: dores (0 – 9,6) — lá menor escuro, tic-tac e pulso grave
    A = [(0.0, [57, 60, 64], 45), (2.4, [53, 57, 60], 41), (4.8, [50, 53, 57, 62], 38), (7.2, [52, 56, 59], 40)]
    for k, (t0, notes, root) in enumerate(A):
        pads.add(t0 - 0.05, pad_chord(notes, 2.75, 850 + 160 * k), 0.22)
        if t0 >= 2.4:                   # pulso em colcheias (tensão crescente)
            for e in range(8):
                n8 = int(0.28 * SR)
                pz = lp(saw(mtof(root + 12), n8), 700 + 120 * k) * env_ad(n8, 0.004, 0.09)
                mb.add(t0 + e * 0.3, pz, 0.05 + 0.015 * k + (0.012 if e % 2 == 0 else 0), pan=-0.2 if e % 2 else 0.2)
        b = np.sin(2 * np.pi * mtof(root) * T(int(2.5 * SR))) * env_asr(int(2.5 * SR), 0.08, 0.35)
        mb.add(t0, b, 0.26)
    for i in range(int(9.6 / 0.3)):
        t0 = i * 0.3
        on_beat = i % 2 == 0
        g = (0.10 if on_beat else 0.05) * (1.5 if 2.4 <= t0 < 4.8 else 1.0)
        if not on_beat and not (2.4 <= t0 < 4.8):
            continue
        drums.add(t0, tick(2600 if (i // 2) % 2 == 0 else 1950, 1.0), g, pan=0.25 if on_beat else -0.25)
    for t0 in (2.4, 4.8, 7.2):          # batida grave tipo coração (lub-dub)
        drums.add(t0, kick(1.0, 120, 40, 0.5), 0.55)
        drums.add(t0 + 0.18, kick(1.0, 100, 38, 0.4), 0.32)
    drums.add(8.4, kick(1.0, 120, 40, 0.5), 0.45)
    drums.add(8.58, kick(1.0, 100, 38, 0.4), 0.28)

    # ---- B: virada (9,6 – 12,0) — sol, riser, notas subindo
    pads.add(9.55, pad_chord([55, 59, 62, 67], 2.35, 1600, att=0.5, rel=0.2), 0.30)
    mb.add(9.6, np.sin(2 * np.pi * mtof(43) * T(int(2.3 * SR))) * env_asr(int(2.3 * SR), 0.1, 0.2), 0.28)
    mb.add(10.25, riser(1.62), 0.32)
    for k in range(16):                 # caixa em 16 avos crescendo
        t0 = 11.0 + k * 0.05
        if t0 < 11.82:
            drums.add(t0, clap(0.5 + 0.5 * k / 16), 0.10 + 0.16 * k / 16)

    # ---- C: solução (12,0 – 27,6) — dó maior, groove
    C = [(12.0, [60, 64, 67, 72], 36), (14.4, [59, 62, 67, 71], 43), (16.8, [57, 60, 64, 69], 45), (19.2, [57, 60, 65, 69], 41),
         (21.6, [60, 64, 67, 72], 36), (24.0, [59, 62, 67, 71], 43), (26.4, [57, 60, 65, 69], 41)]
    ARP = {36: [60, 64, 67, 72, 76, 72, 67, 64], 43: [59, 62, 67, 71, 74, 71, 67, 62], 45: [57, 60, 64, 69, 72, 69, 64, 60], 41: [57, 60, 65, 69, 72, 69, 65, 60]}
    for t0, notes, root in C:
        pads.add(t0 - 0.04, pad_chord(notes, 2.6, 2600, det=0.1, att=0.12, rel=0.35), 0.22)
        for e in range(8):              # baixo em colcheias com "ducking"
            tt = t0 + e * 0.3
            mb.add(tt, bass(mtof(root), 0.27, 1.0), 0.30 if e % 2 == 0 else 0.22)
        seq = ARP[root]
        for s16 in range(16):           # arpejo em semicolcheias
            tt = t0 + s16 * 0.15
            m = seq[s16 % 8] + 12
            pads.add(tt, pluck(mtof(m), 0.45, 1.2), 0.075 if s16 % 4 else 0.1, pan=-0.35 if s16 % 2 else 0.35)
    for b in range(int((27.6 - 12.0) / BEAT) + 2):
        tt = 12.0 + b * BEAT
        if tt >= 28.8:
            break
        if b % 2 == 0:
            drums.add(tt, kick(1.0), 0.78)
        else:
            drums.add(tt, clap(), 0.42)
        drums.add(tt, hat(False), 0.5)
        drums.add(tt + 0.3, hat(b % 4 == 3), 0.72)
    for k in range(8):                  # virada de bateria antes da tela final
        drums.add(27.0 + k * 0.075, clap(0.6 + 0.4 * k / 8), 0.12 + 0.12 * k / 8)

    # ---- D: tela final — resolve em dó
    pads.add(27.55, pad_chord([60, 64, 67, 72], 1.35, 2800, att=0.08, rel=0.3), 0.22)
    pads.add(28.75, pad_chord([48, 60, 64, 67, 72, 76], 1.25, 3200, att=0.06, rel=0.8), 0.28)
    mb.add(28.8, np.sin(2 * np.pi * mtof(36) * T(int(1.2 * SR))) * env_asr(int(1.2 * SR), 0.01, 0.9), 0.32)
    for k, m in enumerate((76, 79, 84)):
        pads.add(28.8 + k * 0.15, bell(mtof(m), 1.4), 0.10, pan=(-0.3, 0, 0.3)[k])

    wet = reverb(pads.x, decay=2.2, mix=0.32)
    # ducking leve de pads e baixo quando o bumbo bate na parte C (a bateria não é afetada)
    duck = np.ones(N)
    for b in range(0, 28):
        tt = 12.0 + b * 1.2
        i = int(tt * SR)
        k = int(0.25 * SR)
        if i + k < N:
            duck[i:i + k] = np.minimum(duck[i:i + k], 0.72 + 0.28 * np.linspace(0, 1, k) ** 0.7)
    out = (wet + mb.x) * duck[:, None] + reverb(drums.x, decay=0.7, mix=0.10)
    # silêncio curto antes do drop
    gap = np.ones(N)
    i0, i1 = int(11.84 * SR), int(12.0 * SR)
    gap[i0:i1] = np.linspace(1, 0.08, i1 - i0) ** 2
    out *= gap[:, None]
    return out


# ============================================================ SFX timeline
def ecg_peak_times():
    L = contour_lengths(ECG)
    fr = np.linspace(0, 1, 4000)
    ys = np.array([point_at(ECG, f)[0][1] for f in fr])
    xs = np.array([point_at(ECG, f)[0][0] for f in fr])
    peaks = []
    for x0 in (133, 288):
        m = (xs > x0 - 30) & (xs < x0 + 30)
        f = fr[m][np.argmin(ys[m])]
        peaks.append(f)
    flat = fr[np.argmax(xs > 380)]
    inv = lambda y: 1 - (1 - y) ** (1 / 3)
    return [0.10 + 1.6 * inv(f) for f in peaks], 0.10 + 1.6 * inv(flat)


def sfx():
    fx = Bus()
    # P1
    fx.add(0.0, scratch(0.6), 0.05)
    peaks, t_flat = ecg_peak_times()
    for tp in peaks:
        fx.add(tp, beep(988, 0.1), 0.12, pan=-0.4)
    fl = beep(988, 1.25) * np.linspace(1, 0, int(1.25 * SR)) ** 1.5
    fx.add(t_flat + 0.15, fl, 0.045, pan=0.1)
    fx.add(0.8, pop(380, 300, 0.12), 0.06)
    # P2 — ponteiros acelerando
    fx.add(2.4, scratch(0.55), 0.05)
    k, tt = 0, 2.65
    while tt < 4.55:
        fx.add(tt, tick(3400 if k % 2 else 2900, 1.0, 0.025), 0.035, pan=0.15)
        tt += max(0.035, 0.14 - 0.05 * (tt - 2.65))
        k += 1
    for j in range(6):
        fx.add(2.68 + j * 0.05, pop(600 + 40 * j, 1100 + 40 * j), 0.025, pan=(-0.6, 0.6)[j % 2])
    # wipe
    fx.add(4.8, marker(0.45), 0.08, pan=-0.2)
    # P3
    fx.add(4.85, scratch(0.5), 0.045, pan=-0.4)
    fx.add(5.05, coin(), 0.12, pan=-0.45)
    for j in range(7):
        fx.add(5.18 + j * 0.07, tick(4200, 1.0, 0.02), 0.025, pan=-0.2 + 0.08 * j)
    fx.add(5.6, tick(1800, 1.0, 0.05) + 0.5 * tick(900, 1.0, 0.05), 0.06)
    fx.add(5.0, scratch(0.7, 1800, 6000, 6), 0.035, pan=0.45)
    fx.add(5.4, swell(196, 0.9) * 0.8, 0.05, pan=0.4)
    # P4
    xs = [250, 805, 540, 232, 852, 560]
    for j in range(6):
        fx.add(7.2 + j * 0.07, pop(420 + 30 * j, 820 + 40 * j), 0.04, pan=(xs[j] - 540) / 540 * 0.7)
    fx.add(8.25, rip(0.5), 0.05, pan=-0.2)
    fx.add(8.95, rip(0.35), 0.035, pan=0.3)
    # virada
    fx.add(9.65, swell(262, 1.0), 0.05)
    fx.add(9.95, pop(300, 700, 0.12), 0.06)
    for j, m in enumerate((72, 74, 76, 79, 81, 84)):
        fx.add(S['pv'] + CONN_T[j] + 0.32, pluck(mtof(m), 0.6, 1.5), 0.11, pan=(-0.5, 0.5, 0.5, -0.5, 0.0, 0.0)[j])
    # revelação
    fx.add(12.0, boom(1.6), 0.36)
    fx.add(12.0, growl(1.1), 0.16)
    fx.add(12.0, hp(rng.standard_normal(int(0.4 * SR)), 2500) * np.exp(-T(int(0.4 * SR)) * 9), 0.06)
    fx.add(12.82, tick(2200, 1.0, 0.05), 0.05)
    fx.add(12.85, pop(500, 900), 0.05)
    fx.add(12.95, glass(1568), 0.05)
    # painel
    fx.add(15.0, swell(330, 1.0), 0.06)
    fx.add(15.5, glass(2093), 0.035)
    fx.add(15.05, scratch(0.8), 0.03)
    for j, tt in enumerate((15.55, 15.65, 15.75, 15.85)):
        fx.add(tt, pop(520 + 60 * j, 1000 + 60 * j), 0.03)
    tt = 15.75
    while tt < 16.45:
        fx.add(tt, tick(3800, 1.0, 0.02), 0.022)
        tt += 0.03 + 0.12 * (tt - 15.75) ** 2
    for j in range(5):
        fx.add(15.95 + j * 0.08, tick(3000 + 200 * j, 1.0, 0.03), 0.03)
    # F2
    fx.add(17.4, swell(392, 0.8), 0.04)
    for j, m in enumerate((72, 76, 79, 84, 88)):
        fx.add(S['f2'] + 0.6 + j * 0.11, chime(mtof(m), 0.7), 0.08, pan=0.3)
    # F3
    fx.add(19.8, flick(), 0.06)
    fx.add(20.2, swell(523, 0.9) * 0.7, 0.03)
    tt = 20.25
    while tt < 21.0:
        fx.add(tt, tick(3600, 1.0, 0.02), 0.02, pan=-0.2)
        tt += 0.03 + 0.1 * (tt - 20.25) ** 2
    fx.add(20.35, scratch(0.9, 2400, 7500, 7), 0.03, pan=-0.1)
    fx.add(20.78, chime(1046, 0.9), 0.08)
    # F4 — conversa
    fx.add(22.2, swell(294, 0.8), 0.04)
    fx.add(22.25, glass(1760), 0.025)
    for key, hi in (('b1', True), ('b2', False), ('b3', True), ('b4', False)):
        fx.add(S['f4'] + F4T[key], pop(700, 1300) if hi else pop(420, 760), 0.05, pan=0.3 if hi else -0.3)
    for t0, t1 in (F4T['ty1'], F4T['ty2']):
        tt = S['f4'] + t0
        while tt < S['f4'] + t1:
            fx.add(tt, tick(5000, 1.0, 0.015), 0.012, pan=-0.3)
            tt += 0.06
    fx.add(S['f4'] + F4T['chip'], chime(1318, 0.8), 0.1)
    fx.add(S['f4'] + F4T['chip'] + 0.1, chime(1760, 0.8), 0.08)
    fx.add(S['f4'] + F4T['line'], marker(0.4), 0.05, pan=0.4)
    fx.add(S['f4'] + F4T['person'], pop(400, 800, 0.1), 0.06, pan=0.6)
    fx.add(S['f4'] + F4T['person'] + 0.05, chime(988, 1.0), 0.08, pan=0.6)
    # F5
    fx.add(25.2, flick(0.2), 0.06, pan=-0.3)
    for j in range(3):
        fx.add(25.32 + j * 0.1, pop(520 + 50 * j, 980 + 50 * j), 0.035)
    # tela final
    fx.add(27.6, swell(262, 1.2), 0.06)
    fx.add(27.75, boom(1.2) * 0.6, 0.18)
    fx.add(28.2, tick(2200, 1.0, 0.05), 0.04)
    fx.add(28.22, glass(2093), 0.045)
    fx.add(28.75, marker(0.45), 0.04)
    fx.add(29.0, chime(1568, 1.0), 0.1)
    return reverb(fx.x, decay=0.9, mix=0.14)


# ============================================================ mix / loudness
def limiter(x, ceil=0.84, look=0.004, rel=0.08):
    from scipy.ndimage import maximum_filter1d
    a = np.abs(x).max(1)
    k = int(look * SR)
    g = np.minimum(1.0, ceil / np.maximum(maximum_filter1d(a, size=2 * k + 1), 1e-9))   # já antecipa o pico (lookahead)
    alpha = math.exp(-1.0 / (rel * SR))
    gs = np.empty_like(g)
    cur = 1.0
    for i in range(len(g)):            # ataque instantâneo, liberação suave
        cur = g[i] if g[i] < cur else g[i] + (cur - g[i]) * alpha
        gs[i] = cur
    gs = np.minimum(np.convolve(gs, np.ones(k) / k, mode='same'), g)
    return x * gs[:, None]


def lufs(path):
    r = subprocess.run(['ffmpeg', '-hide_banner', '-nostats', '-i', path, '-af', 'loudnorm=I=-14:TP=-1:LRA=11:print_format=json', '-f', 'null', '-'],
                       capture_output=True, text=True)
    js = r.stderr[r.stderr.rfind('{'):r.stderr.rfind('}') + 1]
    d = json.loads(js)
    return float(d['input_i']), float(d['input_tp'])


def write(path, x):
    wavfile.write(path, SR, (np.clip(x, -1, 1) * 32767).astype(np.int16))


if __name__ == '__main__':
    os.chdir(HERE)
    m = music()
    f = sfx()
    fade = np.ones(N)
    k = int(0.7 * SR)
    fade[-k:] = np.linspace(1, 0, k) ** 1.6
    m *= fade[:, None]
    f *= fade[:, None]
    f = f * 2.0                          # efeitos ~6 dB mais presentes (não há narração)
    mix = m * 1.0 + f
    pk = np.abs(mix).max()
    mix, m, f = mix / pk * 0.7, m / pk * 0.7, f / pk * 0.7
    write('_pre.wav', mix)
    I, tp = lufs('_pre.wav')
    g = 10 ** ((-14.0 - I) / 20)
    mix, m, f = mix * g, m * g, f * g
    ceil = 10 ** (-1.6 / 20)
    mix = limiter(mix, ceil=ceil)
    write('mix.wav', mix)
    write('musica_stem.wav', limiter(m, ceil=ceil))
    write('sfx_stem.wav', limiter(f, ceil=ceil))
    I2, tp2 = lufs('mix.wav')
    print(json.dumps({'pre_I': I, 'gain_db': 20 * math.log10(g), 'final_I': I2, 'final_TP': tp2}))
