"""RUGE + Nexo — teaser 30 s, 1080x1920, 30 fps (sem narração).
Uso:  python3 teaser.py A B          -> renderiza quadros A..B-1 em out/
      python3 teaser.py test t1 t2.. -> renderiza só esses tempos (s) em test/
"""
import os, sys, math
import numpy as np
import cv2
import skia
from gfx import *

DUR = 30.0
N = int(round(DUR * FPS))
# ---------------------------------------------------------------- timeline (s) — 100 BPM, 1 batida = 0,6 s
S = dict(p1=0.0, p2=2.4, p3=4.8, p4=7.2, pv=9.6, rv=12.0, f1=15.0, f2=17.4, f3=19.8, f4=22.2, f5=25.2, end=27.6)
WIPE = 0.45   # line wipe p2 -> p3
IRIS = 0.55   # iris pv -> rv
EXPAND = 0.5  # phone screen -> end card

# ---------------------------------------------------------------- static layers
def build_bg():
    s = skia.Surface(W, H)
    c = s.getCanvas()
    p = skia.Paint()
    p.setShader(skia.GradientShader.MakeRadial(skia.Point(540, 820), 1350, [CI(BG_C), CI((15, 13, 11)), CI(BG_E)], [0.0, 0.55, 1.0]))
    c.drawPaint(p)
    g = 60
    for k in range(-10, 11):
        x = 540 + k * g + 0.5
        c.drawLine(x, 0, x, H, PS(IVORY, 0.046 if k % 4 == 0 else 0.022, 1, cap='butt'))
    for k in range(-13, 22):
        y = 690 + k * g + 0.5
        c.drawLine(0, y, W, y, PS(IVORY, 0.046 if k % 4 == 0 else 0.022, 1, cap='butt'))
    for kx in range(-8, 9, 4):
        for ky in range(-12, 22, 4):
            x, y = 540 + kx * g + 0.5, 690 + ky * g + 0.5
            c.drawLine(x - 7, y, x + 7, y, PS(IVORY, 0.13, 1.2, cap='butt'))
            c.drawLine(x, y - 7, x, y + 7, PS(IVORY, 0.13, 1.2, cap='butt'))
    v = skia.Paint()
    v.setShader(skia.GradientShader.MakeRadial(skia.Point(540, 860), 1180, [CI(BG_E, 0), CI(BG_E, 0), CI(BG_E, 0.55), CI(BG_E, 0.93)], [0, 0.40, 0.78, 1.0]))
    c.drawPaint(v)
    return s.makeImageSnapshot()


BG = build_bg()
_rng = np.random.default_rng(11)
DUST = [(_rng.uniform(0, W), _rng.uniform(0, H), int(_rng.integers(0, 3)), _rng.uniform(0, 6.28), _rng.uniform(6, 20)) for _ in range(70)]
_rng2 = np.random.default_rng(5)
NET = []
while len(NET) < 24:
    x, y = _rng2.uniform(40, W - 40), _rng2.uniform(250, 1520)
    if 270 < x < 810 and y < 1200:
        continue
    NET.append((x, y, _rng2.uniform(0, 6.28)))
EDGES = [(i, j) for i in range(len(NET)) for j in range(i + 1, len(NET)) if math.hypot(NET[i][0] - NET[j][0], NET[i][1] - NET[j][1]) < 250]
_rng3 = np.random.default_rng(23)
GRAIN = [np.clip(_rng3.normal(0, 3.4, (H, W)), -9, 9).astype(np.int16) for _ in range(6)]


def draw_dust(c, t, a=1.0):
    for x0, y0, z, ph, sp in DUST:
        y = (y0 - sp * (0.6 + 0.5 * z) * t) % (H + 60) - 30
        x = x0 + 14 * math.sin(t * 0.35 + ph)
        al = (0.10, 0.15, 0.2)[z] * (0.65 + 0.35 * math.sin(t * 1.1 + ph * 2.0)) * a
        c.drawCircle(x, y, (0.9, 1.5, 2.3)[z], PF(IVORY, al, (0, 0.5, 1.3)[z]))


def draw_net(c, t):
    a = eo(pr(t, S['rv'] + 0.2, 1.0)) * (1 - eo(pr(t, S['end'], 0.4)))
    if a <= 0.01:
        return
    pts = [(x + 10 * math.sin(t * 0.3 + ph), y + 8 * math.cos(t * 0.25 + ph)) for x, y, ph in NET]
    for i, j in EDGES:
        c.drawLine(*pts[i], *pts[j], PS(IVORY, 0.06 * a, 1, cap='butt'))
    for k, (i, j) in enumerate(EDGES[::3]):
        f = (t * 0.35 + k * 0.37) % 1.0
        x = lerp(pts[i][0], pts[j][0], f)
        y = lerp(pts[i][1], pts[j][1], f)
        c.drawCircle(x, y, 2.2, PF(ORANGE, 0.45 * a * math.sin(math.pi * f)))
    for x, y in pts:
        c.drawCircle(x, y, 2.4, PF(IVORY, 0.22 * a))


def corners(c, t):
    m, L = 46.0, 52.0
    q = eio(pr(t, S['end'] + 0.12, 0.65))
    box0 = (m, m, W - m, H - m)
    box1 = (150, 548, W - 150, 1330)
    x0, y0, x1, y1 = [lerp(box0[i], box1[i], q) for i in range(4)]
    L = lerp(L, 70, q)
    a = 0.26 + 0.34 * q
    k = eo(pr(t, 0.0, 0.7))
    for (x, y, sx, sy) in [(x0, y0, 1, 1), (x1, y0, -1, 1), (x0, y1, 1, -1), (x1, y1, -1, -1)]:
        spath(c, poly([(x, y + sy * L), (x, y), (x + sx * L, y)]), ORANGE if q > 0.5 else IVORY, a, 2, p=k)


def fig_label(c, lt, t_in, num, label, a=1.0):
    q = eo(pr(lt, t_in, 0.45))
    if q <= 0:
        return
    f = font('condm', 24)
    x, y = 96, 300
    s1 = f'FIG. {num:02d}'
    w = text(c, s1, x, y, f, ORANGE, 0.9 * q * a, track=0.22)
    spath(c, poly([(x + w + 16, y - 8), (x + w + 16 + 44 * q, y - 8)]), IVORY, 0.4 * a, 1.4)
    text(c, label, x + w + 76, y, f, IVORY, 0.5 * q * a, track=0.22)


def kicker(c, t, s, t_in, t_out, y=1166, size=30):
    f = font('condm', size)
    track = 0.34
    o = eio(pr(t, t_out, 0.25))
    a = 1 - o
    if a <= 0.004:
        return
    w = letters(c, s, 540, y, f, t, t_in, stagger=0.016, dur=0.32, track=track, rise=10, a=a, color=ORANGE, blur=4)
    L = 60 * eo(pr(t, t_in + 0.2, 0.6))
    gap, yy = 26, y - size * 0.34
    if L > 0.5:
        for sgn in (-1, 1):
            xa = 540 + sgn * (w / 2 + gap)
            spath(c, poly([(xa, yy), (xa + sgn * L, yy)]), ORANGE, 0.7 * a, 2)
            c.drawCircle(xa + sgn * (L + 7), yy, 2.6, PF(ORANGE, 0.85 * a * eo(pr(t, t_in + 0.6, 0.3))))


def colored_word(c, s, x0, y, f, colors, a, track):
    ws = f.getWidths(f.textToGlyphs(s))
    xx = x0
    for ch, wv, col in zip(s, ws, colors):
        c.drawString(ch, xx, y, f, PF(col, a))
        xx += wv + track * f.getSize()


# ================================================================= P1 — "Postou… e ninguém viu?"
ECG_Y = 700


def _ecg():
    y = ECG_Y
    p = skia.Path()
    p.moveTo(-40, y)
    for x in (70, 225):
        p.lineTo(x, y); p.quadTo(x + 12, y - 16, x + 24, y); p.lineTo(x + 40, y)
        p.lineTo(x + 50, y + 20); p.lineTo(x + 63, y - 150); p.lineTo(x + 77, y + 58); p.lineTo(x + 88, y)
        p.lineTo(x + 108, y); p.quadTo(x + 128, y - 28, x + 148, y)
    p.lineTo(W + 40, y)
    return p


ECG = _ecg()


def scene_p1(c, t):
    lt = t - S['p1']
    fig_label(c, lt, 0.15, 1, 'SEM ALCANCE')
    glow_blob(c, 540, 700, 560, ORANGE, 0.05)
    p = eo(pr(lt, 0.10, 1.6))
    spath(c, ECG, ORANGE, 0.95, 3.2, p=p, glow=0.9)
    if 0 < p < 0.999:
        (x, y), _ = point_at(ECG, p)
        glow_blob(c, x, y, 36, ORANGE, 0.65)
        c.drawCircle(x, y, 5.5, PF(IVORY, 0.95))
    k = eo(pr(lt, 0.0, 0.3))
    c.drawRRect(rrect(390, 400, 300, 600, 44), PF(SCREEN, 0.97 * k))
    spath(c, rrect_path(390, 400, 300, 600, 44), IVORY, 0.9, 2.6, p=eo(pr(lt, 0.0, 0.6)))
    spath(c, rrect_path(399, 409, 282, 582, 36), IVORY, 0.16, 1.2, p=eo(pr(lt, 0.1, 0.6)))
    c.drawRRect(rrect(506, 420, 68, 20, 10), PF(IVORY, 0.22 * k))
    hq = eo(pr(lt, 0.25, 0.35))
    spath(c, circle_path(424, 466, 13), IVORY, 0.7, 1.8, p=hq)
    spath(c, poly([(447, 460), (560, 460)]), IVORY, 0.38, 7, p=hq)
    spath(c, poly([(447, 476), (512, 476)]), IVORY, 0.2, 5, p=hq)
    iq = eo(pr(lt, 0.3, 0.45))
    sq = (406, 496, 268, 268)
    if iq > 0:
        c.save()
        c.clipRRect(rrect(*sq, 12), skia.ClipOp.kIntersect, True)
        hp = skia.Path()
        for d in range(-280, 280, 15):
            hp.moveTo(sq[0] + d, sq[1])
            hp.lineTo(sq[0] + d + 280, sq[1] + 280)
        c.drawPath(hp, PS(IVORY, 0.09 * iq, 1.2, cap='butt'))
        c.restore()
        spath(c, rrect_path(*sq, 12), IVORY, 0.75, 2, p=iq)
        spath(c, ic_photo(540, 632, 110), IVORY, 0.6, 2.2, p=eo(pr(lt, 0.45, 0.45)), mode='par')
    for k_, (nm, x) in enumerate([('heart', 426), ('comment', 476), ('send', 526)]):
        spath(c, ICONS[nm](x, 800, 34), IVORY, 0.85, 2.2, p=eo(pr(lt, 0.55 + k_ * 0.06, 0.35)), mode='par')
    q0 = eo(pr(lt, 0.8, 0.4))
    if q0 > 0:
        for j, lab in enumerate((' curtidas', ' comentários')):
            yy = 860 + j * 42 + (1 - q0) * 10
            w0 = text(c, '0', 410, yy, font('cond', 40), ORANGE, q0)
            text(c, lab, 410 + w0, yy, font('sansm', 26), IVORY, 0.8 * q0)
    spath(c, poly([(412, 948), (640, 948)]), IVORY, 0.18, 6, p=eo(pr(lt, 0.7, 0.4)))
    spath(c, poly([(412, 972), (560, 972)]), IVORY, 0.12, 6, p=eo(pr(lt, 0.75, 0.4)))


# ================================================================= P2 — "Sem tempo… e sem ideia do que postar?"
CLK, CR = (540, 700), 215
ORB_RX, ORB_RY, ORB_TILT = 410, 116, -13
CHIPS = ['caixa', 'balcão', 'pedidos', 'entregas', 'fornecedor', 'estoque']


def orbit_pt(th):
    x, y = ORB_RX * math.cos(th), ORB_RY * math.sin(th)
    a = math.radians(ORB_TILT)
    return CLK[0] + x * math.cos(a) - y * math.sin(a), CLK[1] + x * math.sin(a) + y * math.cos(a), math.sin(th)


def _orbit():
    p = skia.Path()
    for i in range(0, 361, 3):
        x, y, _ = orbit_pt(math.radians(i))
        (p.moveTo if i == 0 else p.lineTo)(x, y)
    return p


ORBIT = _orbit()


def chip(c, x, y, s, sc, a):
    if a <= 0.004:
        return
    f = font('sansm', 30 * sc)
    w, h = tw(s, f) + 60 * sc, 54 * sc
    c.drawRRect(rrect(x - w / 2, y - h / 2, w, h, h / 2), PF(BG_C, 0.96 * a))
    c.drawRRect(rrect(x - w / 2, y - h / 2, w, h, h / 2), PS(IVORY, 0.62 * a, 1.8))
    c.drawCircle(x - w / 2 + 22 * sc, y, 4.5 * sc, PF(ORANGE, 0.95 * a))
    text(c, s, x - w / 2 + 38 * sc, y + 10.5 * sc, f, IVORY, 0.92 * a)


def scene_p2(c, t):
    lt = t - S['p2']
    fig_label(c, lt, 0.05, 2, 'SEM TEMPO')
    glow_blob(c, 540, 700, 560, ORANGE, 0.05)
    spath(c, ORBIT, IVORY, 0.38, 1.8, p=eo(pr(lt, 0.1, 0.6)), dash=(0.1, 11))
    chips = []
    for k, s in enumerate(CHIPS):
        th = 2 * math.pi * k / len(CHIPS) + 1.05 * lt + 0.35
        x, y, d = orbit_pt(th)
        chips.append((d, x, y, s, eo(pr(lt, 0.28 + k * 0.05, 0.35))))
    for d, x, y, s, a in sorted(ch for ch in chips if ch[0] < 0):
        chip(c, x, y, s, 0.80 + 0.2 * (d + 1) / 2, a * (0.35 + 0.65 * (d + 1) / 2))
    k = eo(pr(lt, 0.0, 0.3))
    c.drawCircle(*CLK, CR, PF(SCREEN, 0.97 * k))
    spath(c, circle_path(*CLK, CR), IVORY, 0.92, 2.6, p=eo(pr(lt, 0.0, 0.55)))
    spath(c, circle_path(*CLK, CR - 16), IVORY, 0.28, 1.2, p=eo(pr(lt, 0.08, 0.55)))
    for i in range(60):
        q = pr(lt, 0.12 + i * 0.005, 0.12)
        if q <= 0:
            continue
        a = math.radians(-90 + i * 6)
        major = i % 5 == 0
        r0, r1 = (CR - 48, CR - 26) if major else (CR - 38, CR - 26)
        c.drawLine(CLK[0] + r0 * math.cos(a), CLK[1] + r0 * math.sin(a), CLK[0] + r1 * math.cos(a), CLK[1] + r1 * math.sin(a),
                   PS(IVORY, (0.9 if major else 0.42) * q, 3 if major else 1.4))
    hk = eo(pr(lt, 0.22, 0.45))
    rev = 0.35 * lt + 0.5 * lt * lt

    def hand(ang, length, w, rgb, a, tail=24):
        r = math.radians(ang)
        c.drawLine(CLK[0] - tail * math.cos(r), CLK[1] - tail * math.sin(r), CLK[0] + length * math.cos(r), CLK[1] + length * math.sin(r), PS(rgb, a, w))
    if hk > 0:
        hand(-90 + 360 * rev / 12 + 50, 112 * hk, 6.5, IVORY, 0.95 * hk, 18)
        hand(-90 + 360 * rev, 162 * hk, 4.2, IVORY, 0.95 * hk, 22)
        sec = -90 + 360 * (1.1 * lt + 0.8 * lt * lt)
        for j in range(5):
            hand(sec - j * 6.5, 182 * hk, 2.2, ORANGE, hk * (0.95 if j == 0 else 0.24 / j), 30)
        node(c, *CLK, a=hk, s=0.9, ring=True, glow=0.5)
    for d, x, y, s, a in sorted(ch for ch in chips if ch[0] >= 0):
        chip(c, x, y, s, 0.80 + 0.2 * (d + 1) / 2, a * (0.35 + 0.65 * (d + 1) / 2))


# ================================================================= P3 — "Paga alguém… e não vê o que foi feito?"
COIN = (300, 560)
PANEL = (615, 570, 290, 380)
CONN = cubic((398, 590), (500, 572), (512, 790), (611, 764))


def scene_p3(c, t):
    lt = t - S['p3']
    fig_label(c, lt, 0.1, 3, 'TRABALHO INVISÍVEL')
    glow_blob(c, 540, 700, 560, ORANGE, 0.05)
    c.drawCircle(*COIN, 96, PF(SCREEN, 0.95 * eo(pr(lt, 0.0, 0.3))))
    spath(c, circle_path(*COIN, 96), IVORY, 0.9, 2.6, p=eo(pr(lt, 0.05, 0.5)))
    spath(c, circle_path(*COIN, 83), IVORY, 0.32, 1.2, p=eo(pr(lt, 0.12, 0.5)))
    q = eo(pr(lt, 0.22, 0.4))
    text(c, 'R$', COIN[0], COIN[1] + 33 + (1 - q) * 14, font('cond', 96), IVORY, q, align='c', blur=(1 - q) * 8)
    for i in range(10):
        a = math.radians(i * 36 - 90)
        sq = eo(pr(lt, 0.4 + i * 0.02, 0.3))
        if sq > 0:
            r0, r1 = 112, 112 + 14 * sq
            c.drawLine(COIN[0] + r0 * math.cos(a), COIN[1] + r0 * math.sin(a), COIN[0] + r1 * math.cos(a), COIN[1] + r1 * math.sin(a), PS(IVORY, 0.42, 1.8))
    text(c, 'você paga', COIN[0], 724, font('sansm', 30), IVORY, 0.65 * eo(pr(lt, 0.45, 0.4)), align='c')
    pc = eo(pr(lt, 0.35, 0.6))
    spath(c, CONN, IVORY, 0.75, 3.2, p=min(pc, 0.40), dash=(0.1, 10))
    if pc > 0.6:
        spath(c, CONN, IVORY, 0.75, 3.2, p=pc, p0=0.6, dash=(0.1, 10))
    xq = eob(pr(lt, 0.8, 0.35))
    if xq > 0:
        (mx, my), _ = point_at(CONN, 0.5)
        s = 11 * xq
        for sx in (-1, 1):
            spath(c, poly([(mx - s, my - sx * s), (mx + s, my + sx * s)]), ORANGE, 0.95, 3, glow=0.6)
    x, y, w, h = PANEL
    c.drawRRect(rrect(x, y, w, h, 26), PF(SCREEN, 0.92 * eo(pr(lt, 0.15, 0.3))))
    spath(c, rrect_path(x, y, w, h, 26), IVORY, 0.8, 2.2, p=eo(pr(lt, 0.2, 0.7)), dash=(12, 10), phase=-lt * 24)
    text(c, 'RELATÓRIO', x + w / 2, y - 26, font('condm', 24), IVORY, 0.5 * eo(pr(lt, 0.35, 0.4)), align='c', track=0.3)
    for i, ww in enumerate((200, 150, 180)):
        spath(c, poly([(x + 32, y + 54 + i * 38), (x + 32 + ww, y + 54 + i * 38)]), IVORY, 0.28, 3, p=eo(pr(lt, 0.45 + i * 0.06, 0.4)), dash=(6, 9))
    qm = eo(pr(lt, 0.6, 0.45))
    if qm > 0:
        fy = math.sin(lt * 3.0) * 5 + (1 - qm) * 20
        fq = font('serif_i', 250)
        text(c, '?', x + w / 2, y + 336 + fy, fq, ORANGE, 0.5 * qm, align='c', blur=18)
        text(c, '?', x + w / 2, y + 336 + fy, fq, ORANGE, qm, align='c')


# ================================================================= P4 + virada — "tudo espalhado?" -> "conectado?"
TILES = [('pedidos', 'bag', (250, 440), -8, 210), ('notas', 'receipt', (805, 420), 9, -30),
         ('caixa', 'note', (540, 655), 3, -90), ('redes', 'grid', (232, 870), 11, 150),
         ('mensagens', 'chat', (852, 850), -7, 30), ('números', 'chart', (560, 975), -4, 90)]
HUB, RING = (540, 690), 330
CONNS = [(0, 2), (1, 2), (3, 2), (4, 2), (5, 2), (0, 3), (1, 4)]


def tile_p4(k, lt):
    _, _, (x, y), rot, _ = TILES[k]
    dx, dy = x - HUB[0], y - HUB[1]
    d = math.hypot(dx, dy) or 1.0
    dr = 30 * eo(pr(lt, 0.0, 2.4)) + 6 * max(0.0, lt - 2.4)
    jx, jy = 4 * math.sin(lt * 2.1 + k * 1.7), 4 * math.cos(lt * 1.7 + k * 2.3)
    return x + dx / d * dr + jx, y + dy / d * dr + jy, rot + 2.5 * math.sin(lt * 1.5 + k)


def slot(k):
    a = math.radians(TILES[k][4])
    return HUB[0] + RING * math.cos(a), HUB[1] + RING * math.sin(a)


def tile_pos(k, t):
    lt4 = t - S['p4']
    x, y, r = tile_p4(k, lt4)
    if t < S['pv']:
        return x, y, r
    m = eio(pr(t, S['pv'] + 0.05, 0.85))
    sx, sy = slot(k)
    return lerp(x, sx, m), lerp(y, sy, m), lerp(r, 0.0, m)


def draw_tile(c, k, x, y, rot, a, p_draw, conn=0.0, sc=1.0, size=148):
    name, ic = TILES[k][0], TILES[k][1]
    hs = size / 2
    c.save()
    c.translate(x, y)
    c.rotate(rot)
    c.scale(sc, sc)
    if conn > 0:
        glow_blob(c, 0, 0, 130, ORANGE, 0.14 * conn * a)
    c.drawRRect(rrect(-hs, -hs, size, size, 30), PF(CARD, 0.97 * a))
    spath(c, rrect_path(-hs, -hs, size, size, 30), mixc(IVORY, ORANGE, 0.7 * conn), 0.9 * a, 2.2, p=p_draw)
    spath(c, ICONS[ic](0, 2, 76), IVORY, 0.9 * a, 2.4, p=eo(cl((p_draw - 0.25) / 0.75)), mode='par')
    c.restore()
    text(c, name, x, y + hs * sc + 38, font('sansm', 27), IVORY, 0.72 * a * eo(cl((p_draw - 0.4) / 0.6)), align='c')


def draw_conns(c, pos, lt, a):
    pc = eo(pr(lt, 0.25, 0.5))
    g = 0.2 * eo(pr(lt, 0.8, 1.3))
    for i, j in CONNS:
        path = poly([pos[i][:2], pos[j][:2]])
        spath(c, path, IVORY, 0.42 * a, 1.6, p=min(pc, 0.5 - g), dash=(8, 10))
        if pc > 0.5 + g:
            spath(c, path, IVORY, 0.42 * a, 1.6, p=pc, p0=0.5 + g, dash=(8, 10))


def scene_p4(c, t):
    lt = t - S['p4']
    fig_label(c, lt, 0.05, 4, 'TUDO ESPALHADO')
    glow_blob(c, 540, 700, 560, ORANGE, 0.05)
    pos = [tile_p4(k, lt) for k in range(6)]
    draw_conns(c, pos, lt, 1.0)
    for k in range(6):
        x, y, r = pos[k]
        q = pr(lt, k * 0.07, 0.5)
        draw_tile(c, k, x, y, r, min(1.0, q * 2.2), eo(q), sc=0.86 + 0.14 * eob(q))


def hub_curve(k):
    sx, sy = slot(k)
    vx, vy = HUB[0] - sx, HUB[1] - sy
    d = math.hypot(vx, vy)
    ux, uy = vx / d, vy / d
    px, py = -uy, ux
    p0 = (sx + ux * 84, sy + uy * 84)
    p1 = (HUB[0] - ux * 26, HUB[1] - uy * 26)
    L = d - 110
    c1 = (p0[0] + ux * L * 0.30 + px * L * 0.32, p0[1] + uy * L * 0.30 + py * L * 0.32)
    c2 = (p1[0] - ux * L * 0.42 + px * L * 0.10, p1[1] - uy * L * 0.42 + py * L * 0.10)
    return cubic(p0, c1, c2, p1)


HUB_CURVES = [hub_curve(k) for k in range(6)]
CONN_T = [0.82 + k * 0.11 for k in range(6)]


def scene_pv(c, t):
    lt = t - S['pv']
    fo = 1 - eo(pr(lt, 0.0, 0.3))
    fig_label(c, t - S['p4'], 0.05, 4, 'TUDO ESPALHADO', a=fo)
    glow_blob(c, *HUB, 600, ORANGE, 0.05 + 0.05 * eo(pr(lt, 0.6, 1.2)))
    if fo > 0:
        draw_conns(c, [tile_pos(k, t) for k in range(6)], t - S['p4'], fo)
    spath(c, circle_path(*HUB, 36), IVORY, 0.5, 1.5, p=eo(pr(lt, 0.4, 0.5)))
    spath(c, circle_path(*HUB, 60), IVORY, 0.32, 1.6, p=eo(pr(lt, 0.5, 0.5)), dash=(0.1, 8), phase=-lt * 12)
    for k in range(6):
        pk = eo(pr(lt, CONN_T[k], 0.32))
        if pk <= 0:
            continue
        cv = HUB_CURVES[k]
        spath(c, cv, ORANGE, 0.9, 2.4, p=pk, glow=0.7)
        if pk >= 0.999:
            for j in range(2):
                f = ((lt - CONN_T[k] - 0.32) * 0.95 + j * 0.5) % 1.0
                (dx, dy), _ = point_at(cv, f)
                glow_blob(c, dx, dy, 15, ORANGE, 0.55)
                c.drawCircle(dx, dy, 3.2, PF(IVORY, 0.95))
        pp = pr(lt, CONN_T[k] + 0.32, 0.55)
        if 0 < pp < 1:
            spath(c, circle_path(*HUB, 16 + 84 * eo(pp)), ORANGE, 0.55 * (1 - pp), 2)
    for k in range(6):
        x, y, r = tile_pos(k, t)
        draw_tile(c, k, x, y, r, 1.0, 1.0, conn=eo(pr(lt, CONN_T[k] + 0.22, 0.3)))
    hq = eob(pr(lt, 0.35, 0.5))
    if hq > 0:
        node(c, *HUB, a=min(1.0, hq * 1.6), s=1.35 * max(hq, 0.01), glow=0.9)


# ================================================================= revelação — RUGE + NEXO
NEXO_COLORS = [IVORY, IVORY, ORANGE, IVORY]


def scene_rv(c, t):
    lt = t - S['rv']
    out = eo(pr(t, S['f1'], 0.32))
    a = 1 - out
    if a <= 0.004:
        return
    cx, cy = 540, 880
    dq = eo(pr(lt, 0.1, 0.9))
    glow_blob(c, cx, cy, 660, ORANGE, 0.085 * a)
    for r, al in ((300, 0.10), (430, 0.07), (560, 0.05)):
        spath(c, circle_path(cx, cy, r), IVORY, al * a, 1.2, p=dq)
    spath(c, circle_path(cx, cy, 430, start=-90 + lt * 8), IVORY, 0.28 * a, 2, p=dq, dash=(0.1, 16))
    for i in range(36):
        an = math.radians(i * 10 + lt * 4)
        q = eo(pr(lt, 0.2 + i * 0.01, 0.3))
        if q > 0:
            r0, r1 = 300, 300 + (14 if i % 3 == 0 else 7)
            c.drawLine(cx + r0 * math.cos(an), cy + r0 * math.sin(an), cx + r1 * math.cos(an), cy + r1 * math.sin(an), PS(IVORY, 0.22 * q * a, 1.4))
    dy = -24 * out
    letters(c, 'RUGE', 540, 716 + dy, font('cond', 236), lt, 0.12, stagger=0.07, dur=0.55, track=0.06, rise=56, a=a)
    sq = eo(pr(lt, 0.5, 0.45))
    text(c, 'MARKETING E SOLUÇÕES DIGITAIS', 540, 776 + dy + (1 - sq) * 10, font('condm', 30), IVORY, 0.62 * sq * a, align='c', track=0.3)
    lq = eo(pr(lt, 0.7, 0.35))
    spath(c, poly([(540, 824 + dy), (540, 824 + dy + 92 * lq)]), IVORY, 0.55 * a, 1.6)
    nq = eob(pr(lt, 0.85, 0.4))
    if nq > 0:
        node(c, 540, 870 + dy, a=min(1, nq * 1.6) * a, s=max(nq, 0.01), glow=0.8)
    sq2 = eo(pr(lt, 1.3, 0.45))
    text(c, 'ASSISTENTE INTELIGENTE DO SEU NEGÓCIO', 540, 1140 + dy + (1 - sq2) * 10, font('condm', 27), IVORY, 0.6 * sq2 * a, align='c', track=0.24)
    size = fit_size(['A RUGE *cria*.', 'O Nexo *acompanha*.'], 72, 860)
    headline(c, ['A RUGE *cria*.', 'O Nexo *acompanha*.'], t, S['rv'] + 1.5, None, 540, 1262 + dy, size, size * 1.1, a=a, stagger=0.06)


# ================================================================= painel (celular) — recursos do Nexo
def phone_geom(t):
    PX = 540 - 70 * eio(pr(t, S['f4'], 0.6)) + 70 * eio(pr(t, S['f5'], 0.5))
    PT = 212 + 5 * math.sin((t - S['f1']) * 1.2)
    PW, PH = 470, 950
    return dict(PX=PX, PT=PT, PW=PW, PH=PH, SX=PX - PW / 2 + 13, SY=PT + 13, SW=PW - 26, SH=PH - 26)


def nexo_word(c, t):
    if t < S['f1']:
        lt = t - S['rv']
        letters(c, 'NEXO', 540, 1084, font('cond', 168), lt, 0.95, stagger=0.07, dur=0.55, track=0.18, rise=50, colors=NEXO_COLORS)
        return
    a = 1 - eo(pr(t, S['end'], 0.3))
    if a <= 0.004:
        return
    k = eio(pr(t, S['f1'], 0.7))
    g = phone_geom(t)
    size, track = lerp(168, 32, k), lerp(0.18, 0.16, k)
    x0 = lerp(540 - tw('NEXO', font('cond', 168), 0.18) / 2, g['SX'] + 62, k)
    base = lerp(1084, g['SY'] + 104, k)
    colored_word(c, 'NEXO', x0, base, font('cond', size), NEXO_COLORS, a, track)


def draw_phone(c, t, g, a):
    lt = t - S['f1']
    po = eo(pr(lt, 0.05, 0.8))
    fill = eo(pr(lt, 0.05, 0.45))
    x0 = g['PX'] - g['PW'] / 2
    glow_blob(c, g['PX'], g['PT'] + g['PH'] / 2, 640, ORANGE, 0.075 * a)
    rx = x0 - 46
    for i in range(41):
        q = eo(pr(lt, 0.3 + i * 0.008, 0.3))
        if q > 0:
            yy = g['PT'] + 20 + i * 22.5
            L = 15 if i % 5 == 0 else 7
            c.drawLine(rx, yy, rx + L * q, yy, PS(IVORY, (0.24 if i % 5 == 0 else 0.13) * a, 1.3, cap='butt'))
    c.drawRRect(rrect(x0, g['PT'], g['PW'], g['PH'], 66), PF(INK, 0.985 * fill * a))
    spath(c, rrect_path(x0 - 10, g['PT'] - 10, g['PW'] + 20, g['PH'] + 20, 76), IVORY, 0.09 * a, 1.2, p=po)
    spath(c, rrect_path(x0, g['PT'], g['PW'], g['PH'], 66), IVORY, 0.92 * a, 2.6, p=po)
    for (xx, y0, y1) in ((x0 - 3, 190, 255), (x0 - 3, 275, 340), (x0 + g['PW'] + 3, 240, 350)):
        spath(c, poly([(xx, g['PT'] + y0), (xx, g['PT'] + y1)]), IVORY, 0.6 * a, 4, p=eo(pr(lt, 0.45, 0.4)))
    c.drawRRect(rrect(g['SX'], g['SY'], g['SW'], g['SH'], 54), PF(SCREEN, fill * a))
    spath(c, rrect_path(g['SX'], g['SY'], g['SW'], g['SH'], 54), IVORY, 0.14 * a, 1.2, p=po)
    c.drawRRect(rrect(g['PX'] - 62, g['PT'] + 30, 124, 36, 18), PF(IVORY, 0.14 * fill * a))


def card(c, x, y, w, h, a, p=1.0, fill_a=0.75, stroke=IVORY, stroke_a=0.2, r=24):
    c.drawRRect(rrect(x, y, w, h, r), PF(CARD, fill_a * a))
    spath(c, rrect_path(x, y, w, h, r), stroke, stroke_a * a, 1.4, p=p)


def label(c, s, x, y, a, col=IVORY, al=0.55, size=21):
    text(c, s, x, y, font('condm', size), col, al * a, track=0.2)


def card_visib(c, t, x, y, a):
    lt = t - S['f1']
    card(c, x, y, 400, 178, a, p=eo(pr(lt, 0.55, 0.6)))
    label(c, 'VISIBILIDADE', x + 24, y + 42, a)
    tri = poly([(x + 296, y + 36), (x + 304, y + 24), (x + 312, y + 36)], close=True)
    c.drawPath(tri, PF(ORANGE, 0.9 * a))
    text(c, 'subindo', x + 320, y + 40, font('sansm', 20), ORANGE, 0.9 * a)
    k = eo(pr(lt, 0.75, 0.75))
    v = int(round(72 * k))
    nw = text(c, str(v), x + 22, y + 146, font('cond', 96), IVORY, a * eo(pr(lt, 0.65, 0.3)))
    text(c, '/100', x + 26 + nw, y + 146, font('sans', 26), IVORY, 0.42 * a)
    pts = [(0, .15), (.18, .3), (.34, .22), (.5, .5), (.66, .44), (.82, .72), (1, .9)]
    bx0, bx1, by0, by1 = x + 200, x + 378, y + 70, y + 150
    P = [(lerp(bx0, bx1, u), lerp(by1, by0, v_)) for u, v_ in pts]
    sp = eo(pr(lt, 0.8, 0.7))
    path = poly(P)
    if sp > 0:
        (ex, ey), _ = point_at(path, sp)
        fillp = skia.Path()
        fillp.moveTo(P[0][0], by1)
        for px, py in P:
            fillp.lineTo(px, py)
        fillp.lineTo(P[-1][0], by1)
        fillp.close()
        c.save()
        c.clipRect(skia.Rect.MakeLTRB(bx0 - 2, by0 - 20, ex, by1 + 2), skia.ClipOp.kIntersect, True)
        gp = skia.Paint()
        gp.setShader(skia.GradientShader.MakeLinear([skia.Point(0, by0), skia.Point(0, by1)], [CI(ORANGE, 0.22 * a), CI(ORANGE, 0)]))
        c.drawPath(fillp, gp)
        c.restore()
        spath(c, path, ORANGE, a, 3, p=sp, glow=0.6)
        pul = 0.5 + 0.5 * math.sin(lt * 6)
        glow_blob(c, ex, ey, 18 + 6 * pul, ORANGE, 0.5 * a)
        c.drawCircle(ex, ey, 4.5, PF(IVORY, a))


DAYS = ['S', 'T', 'Q', 'Q', 'S', 'S', 'D']


def card_posts_inner(c, t, x, y, a):
    lt = t - S['f1']
    label(c, 'POSTS DA SEMANA', x + 24, y + 42, a)
    n_ok = 0
    for k in range(7):
        bx = x + 24 + k * 52
        by = y + 60
        c.drawRRect(rrect(bx, by, 36, 36, 9), PS(IVORY, 0.32 * a, 1.4))
        text(c, DAYS[k], bx + 18, by + 64, font('condm', 19), IVORY, 0.5 * a, align='c')
        if k < 5:
            q = eo(pr(lt, 0.95 + k * 0.08, 0.3))
            if q > 0:
                c.drawRRect(rrect(bx, by, 36, 36, 9), PF(ORANGE, 0.9 * q * a))
                spath(c, ic_check(bx + 18, by + 18, 21), INK, q * a, 2.8, p=q)
            n_ok += q >= 0.5
    text(c, f'{n_ok} prontos', x + 378, y + 40, font('sansm', 20), ORANGE, 0.9 * a, align='r')


def card_tip(c, t, x, y, a):
    lt = t - S['f1']
    card(c, x, y, 400, 150, a, p=eo(pr(lt, 0.75, 0.6)), stroke=ORANGE, stroke_a=0.4)
    label(c, 'DICA DO NEXO', x + 24, y + 42, a, col=ORANGE, al=0.9)
    spath(c, ic_bulb(x + 46, y + 96, 50), IVORY, 0.85 * a, 2.2, p=eo(pr(lt, 0.9, 0.4)), mode='par')
    text(c, 'Responda os comentários', x + 84, y + 90, font('sansm', 26), IVORY, 0.92 * a)
    text(c, 'em até 1 hora.', x + 84, y + 124, font('sansm', 26), IVORY, 0.92 * a)


def input_bar(c, t, x, y, a):
    c.drawRRect(rrect(x, y, 400, 64, 32), PS(IVORY, 0.28 * a, 1.4))
    text(c, 'Pergunte ao Nexo…', x + 28, y + 40, font('sans', 24), IVORY, 0.42 * a)
    c.drawCircle(x + 368, y + 32, 22, PF(ORANGE, 0.92 * a))
    spath(c, ic_send(x + 369, y + 32, 24), INK, a, 2.2)


ROWS = [('SEG', 'REELS', 'Bastidores do dia'), ('TER', 'CARROSSEL', 'Os 3 mais pedidos'), ('QUA', 'STORY', 'Enquete da semana'),
        ('QUI', 'POST', 'Oferta do dia'), ('SEX', 'REELS', 'Depoimento real')]


def page_f2(c, t, a):
    lt = t - S['f2']
    q = eo(pr(lt, 0.15, 0.4))
    text(c, 'Escala da semana', 24, 70 + (1 - q) * 14, font('cond', 46), IVORY, q * a)
    text(c, 'Sugerida pelo Nexo · revisada pela RUGE', 24, 104 + (1 - q) * 14, font('sans', 20), IVORY, 0.58 * q * a)
    for k, (d, ty, ti) in enumerate(ROWS):
        rq = eo(pr(lt, 0.25 + k * 0.08, 0.45))
        if rq <= 0:
            continue
        y = 132 + k * 124 + (1 - rq) * 24
        ra = rq * a
        card(c, 14, y, 396, 108, ra, r=20, stroke_a=0.16, fill_a=0.7)
        text(c, d, 34, y + 46, font('cond', 30), ORANGE, ra)
        f = font('condm', 17)
        pw = tw(ty, f, 0.16) + 26
        c.drawRRect(rrect(96, y + 20, pw, 30, 15), PS(IVORY, 0.38 * ra, 1.4))
        text(c, ty, 109, y + 41, f, IVORY, 0.82 * ra, track=0.16)
        text(c, ti, 96, y + 86, font('sansm', 25), IVORY, 0.92 * ra)
        spath(c, circle_path(366, y + 54, 19), ORANGE, 0.85 * ra, 2, p=eo(pr(lt, 0.4 + k * 0.08, 0.4)))
        ck = eo(pr(lt, 0.6 + k * 0.11, 0.35))
        if ck > 0:
            c.drawCircle(366, y + 54, 19, PF(ORANGE, 0.16 * ck * a))
            spath(c, ic_check(366, y + 54, 22), ORANGE, ra, 2.6, p=ck)


def page_f3(c, t, a):
    lt = t - S['f3']
    q = 1.0
    text(c, 'Seus números', 24, 70 + (1 - q) * 14, font('cond', 46), IVORY, q * a)
    text(c, 'Últimos 30 dias', 24, 104 + (1 - q) * 14, font('sans', 20), IVORY, 0.58 * q * a)
    cx, cy, R = 212, 316, 138
    spath(c, arc_path(cx, cy, R, 180, 180), IVORY, 0.13 * a, 18, cap='butt', p=eo(pr(lt, 0.05, 0.5)))
    for i in range(11):
        an = math.radians(180 + i * 18)
        tq = eo(pr(lt, 0.1 + i * 0.02, 0.3))
        if tq > 0:
            c.drawLine(cx + (R + 16) * math.cos(an), cy + (R + 16) * math.sin(an), cx + (R + 26) * math.cos(an), cy + (R + 26) * math.sin(an),
                       PS(IVORY, 0.3 * tq * a, 1.6))
    gq = eo(pr(lt, 0.4, 0.85))
    if gq > 0.002:
        spath(c, arc_path(cx, cy, R, 180, 180 * 0.72 * gq), ORANGE, a, 18, cap='round', glow=0.45)
    text(c, str(int(round(72 * gq))), cx, cy - 10, font('cond', 96), IVORY, a * eo(pr(lt, 0.2, 0.3)), align='c')
    text(c, 'visibilidade', cx, cy + 32, font('sans', 23), IVORY, 0.6 * a * q, align='c')
    text(c, '0', cx - R, cy + 36, font('condm', 20), IVORY, 0.4 * a * q, align='c')
    text(c, '100', cx + R, cy + 36, font('condm', 20), IVORY, 0.4 * a * q, align='c')
    cq = eo(pr(lt, 0.15, 0.45))
    if cq > 0:
        y0 = 404 + (1 - cq) * 20
        card(c, 14, y0, 396, 214, cq * a, r=20, stroke_a=0.16)
        label(c, 'ALCANCE · 4 SEMANAS', 34, y0 + 40, cq * a, size=19)
        bx0, bx1, by0, by1 = 38, 386, y0 + 64, y0 + 188
        for gy in (by0, (by0 + by1) / 2, by1):
            c.drawLine(bx0, gy, bx1, gy, PS(IVORY, 0.1 * cq * a, 1, cap='butt', dash=(4, 6)))
        vals = [0.18, 0.32, 0.26, 0.5, 0.42, 0.64, 0.6, 0.86]
        P = [(lerp(bx0, bx1, i / 7), lerp(by1, by0, v)) for i, v in enumerate(vals)]
        path = poly(P)
        sp = eo(pr(lt, 0.55, 0.9))
        if sp > 0:
            (ex, ey), _ = point_at(path, sp)
            fillp = skia.Path()
            fillp.moveTo(P[0][0], by1)
            for px, py in P:
                fillp.lineTo(px, py)
            fillp.lineTo(P[-1][0], by1)
            fillp.close()
            c.save()
            c.clipRect(skia.Rect.MakeLTRB(bx0 - 2, by0 - 30, ex, by1 + 2), skia.ClipOp.kIntersect, True)
            gp = skia.Paint()
            gp.setShader(skia.GradientShader.MakeLinear([skia.Point(0, by0), skia.Point(0, by1)], [CI(ORANGE, 0.24 * a), CI(ORANGE, 0)]))
            c.drawPath(fillp, gp)
            c.restore()
            spath(c, path, ORANGE, a, 3, p=sp, glow=0.6)
            glow_blob(c, ex, ey, 20 + 5 * math.sin(lt * 6), ORANGE, 0.5 * a)
            c.drawCircle(ex, ey, 4.5, PF(IVORY, a))
    iq = eo(pr(lt, 0.95, 0.45))
    if iq > 0:
        y0 = 638 + (1 - iq) * 20
        c.drawRRect(rrect(14, y0, 396, 118, 20), PF(ORANGE, 0.08 * iq * a))
        spath(c, rrect_path(14, y0, 396, 118, 20), ORANGE, 0.45 * iq * a, 1.4)
        spath(c, ic_spark(54, y0 + 58, 40), ORANGE, iq * a, 2.2, p=iq)
        text(c, 'Funcionou: bastidores', 88, y0 + 52, font('sanssb', 25), IVORY, iq * a)
        text(c, 'Faça mais 2 nesta semana.', 88, y0 + 86, font('sans', 21), IVORY, 0.62 * iq * a)


def bubble(c, lines, x, y, side, t, t_on, a, nexo=False):
    q = eo(pr(t, t_on, 0.3))
    f, lh = font('sans', 24), 31
    w = max(tw(s, f) for s in lines) + 40
    h = len(lines) * lh + 26
    if q <= 0:
        return h
    bx = x if side == 'l' else x - w
    yy = y + (1 - q) * 14
    s = 0.9 + 0.1 * eob(q)
    ax, ay = (bx if side == 'l' else bx + w), yy + h
    c.save()
    c.translate(ax, ay)
    c.scale(s, s)
    c.translate(-ax, -ay)
    col = ORANGE if nexo else IVORY
    c.drawRRect(rrect(bx, yy, w, h, 20), PF(col, (0.08 if nexo else 0.07) * q * a))
    c.drawRRect(rrect(bx, yy, w, h, 20), PS(col, (0.6 if nexo else 0.32) * q * a, 1.5))
    for i, s_ in enumerate(lines):
        text(c, s_, bx + 20, yy + 13 + (i + 1) * lh - 7, f, IVORY, 0.93 * q * a)
    c.restore()
    return h


def typing(c, x, y, t, t0, t1, a):
    if not (t0 <= t <= t1):
        return
    q = eo(pr(t, t0, 0.12)) * (1 - eo(pr(t, t1 - 0.08, 0.08)))
    c.drawRRect(rrect(x, y, 84, 44, 20), PS(ORANGE, 0.5 * q * a, 1.5))
    for i in range(3):
        b = math.sin((t - t0) * 14 - i * 0.9)
        c.drawCircle(x + 24 + i * 18, y + 22 - 4 * max(0, b), 4, PF(IVORY, (0.45 + 0.4 * max(0, b)) * q * a))


F4T = dict(b1=0.30, ty1=(0.45, 0.70), b2=0.70, b3=1.00, ty2=(1.15, 1.40), b4=1.40, chip=1.75, line=1.85, person=2.10)


def sheet_f4(c, t, g, a):
    lt = t - S['f4']
    k = eo(pr(lt, 0.0, 0.45))
    if k <= 0:
        return
    SW, SH = g['SW'], g['SH']
    c.drawRect(skia.Rect.MakeXYWH(0, 0, SW, SH), PF(INK, 0.5 * k * a))
    ys = lerp(SH + 30, 140, k)
    c.drawRRect(rrect(8, ys, SW - 16, SH - ys + 80, 30), PF((29, 25, 22), 0.99 * a))
    c.drawRRect(rrect(8, ys, SW - 16, SH - ys + 80, 30), PS(IVORY, 0.18 * a, 1.4))
    c.drawLine(SW / 2 - 30, ys + 16, SW / 2 + 30, ys + 16, PS(IVORY, 0.3 * a, 5))
    node(c, 40, ys + 56, a=a, s=0.8, glow=0.3)
    text(c, 'Nexo', 62, ys + 68, font('cond', 34), IVORY, a)
    c.drawCircle(140, ys + 58, 4.5, PF(ORANGE, a))
    text(c, 'responde na hora', 152, ys + 65, font('sans', 19), IVORY, 0.5 * a)
    y = ys + 96
    h1 = bubble(c, ['Quero vender mais', 'no fim de semana.'], SW - 24, y, 'r', lt, F4T['b1'], a)
    y2 = y + h1 + 14
    typing(c, 24, y2, lt, *F4T['ty1'], a)
    h2 = bubble(c, ['Boa! Posso montar uma', 'campanha pra você.'], 24, y2, 'l', lt, F4T['b2'], a, nexo=True)
    y3 = y2 + h2 + 14
    h3 = bubble(c, ['E o iFood? E o caixa?'], SW - 24, y3, 'r', lt, F4T['b3'], a)
    y4 = y3 + h3 + 14
    typing(c, 24, y4, lt, *F4T['ty2'], a)
    h4 = bubble(c, ['Esse assunto merece uma', 'análise completa. Vou', 'passar pra equipe RUGE.'], 24, y4, 'l', lt, F4T['b4'], a, nexo=True)
    y5 = y4 + h4 + 20
    cq = eob(pr(lt, F4T['chip'], 0.35))
    if cq > 0:
        f = font('sansm', 22)
        s = 'Encaminhado para a RUGE'
        w = tw(s, f) + 76
        x0 = SW / 2 - w / 2
        c.save()
        c.translate(SW / 2, y5 + 25)
        c.scale(max(cq, 0.01), max(cq, 0.01))
        c.translate(-SW / 2, -(y5 + 25))
        c.drawRRect(rrect(x0, y5, w, 50, 25), PF(ORANGE, 0.12 * a))
        c.drawRRect(rrect(x0, y5, w, 50, 25), PS(ORANGE, 0.8 * a, 1.6))
        spath(c, ic_check(x0 + 30, y5 + 25, 22), ORANGE, a, 2.6, p=eo(pr(lt, F4T['chip'] + 0.08, 0.3)))
        text(c, s, x0 + 52, y5 + 33, f, IVORY, a)
        c.restore()
    return (SW / 2 + (tw('Encaminhado para a RUGE', font('sansm', 22)) + 76) / 2, y5 + 25)


def person_out(c, t, g, chip_end):
    lt = t - S['f4']
    a = 1 - eo(pr(t, S['f5'], 0.3))
    if a <= 0.004 or chip_end is None:
        return
    sx, sy = g['SX'] + chip_end[0], g['SY'] + chip_end[1]
    P = (900, 560)
    cv = cubic((sx + 4, sy), (sx + 140, sy), (752, P[1]), (P[0] - 76, P[1]))
    pl = eo(pr(lt, F4T['line'], 0.4))
    if pl > 0:
        spath(c, cv, ORANGE, 0.9 * a, 2.4, p=pl, glow=0.7)
        if pl < 0.999:
            (dx, dy), _ = point_at(cv, pl)
            glow_blob(c, dx, dy, 18, ORANGE, 0.6 * a)
            c.drawCircle(dx, dy, 4, PF(IVORY, a))
        else:
            f = ((lt - F4T['line'] - 0.4) * 1.1) % 1.0
            (dx, dy), _ = point_at(cv, f)
            glow_blob(c, dx, dy, 14, ORANGE, 0.5 * a)
            c.drawCircle(dx, dy, 3.2, PF(IVORY, 0.9 * a))
    pq = eob(pr(lt, F4T['person'], 0.45))
    if pq > 0:
        s = max(pq, 0.01)
        glow_blob(c, *P, 150 * s, ORANGE, 0.12 * a)
        c.drawCircle(*P, 74 * s, PF(CARD, 0.95 * a))
        spath(c, circle_path(*P, 74 * s), ORANGE, 0.9 * a, 2.2, glow=0.6)
        spath(c, circle_path(*P, 88 * s), IVORY, 0.22 * a, 1.2, dash=(0.1, 7))
        spath(c, ic_person(P[0], P[1] + 4, 92 * s), IVORY, 0.92 * a, 2.4, p=eo(pr(lt, F4T['person'] + 0.1, 0.4)), mode='par')
        lq = eo(pr(lt, F4T['person'] + 0.2, 0.4))
        text(c, 'equipe RUGE', P[0], P[1] + 120 + (1 - lq) * 10, font('sansm', 26), IVORY, 0.92 * lq * a, align='c')
        text(c, 'te chama no WhatsApp', P[0], P[1] + 150 + (1 - lq) * 10, font('sans', 21), ORANGE, 0.9 * lq * a, align='c')


SOON = [('bag', 'Pedidos', 'iFood e delivery'), ('receipt', 'Notas fiscais', 'emitidas e organizadas'), ('note', 'Caixa', 'entradas e saídas')]


def page_f5(c, t, a):
    lt = t - S['f5']
    q = 1.0
    text(c, 'Em breve', 24, 70 + (1 - q) * 14, font('cond', 46), IVORY, q * a)
    text(c, 'no mesmo painel', 24, 104 + (1 - q) * 14, font('sans', 20), IVORY, 0.58 * q * a)
    for k, (ic, ti, de) in enumerate(SOON):
        rq = eo(pr(lt, 0.12 + k * 0.1, 0.45))
        if rq <= 0:
            continue
        y = 134 + k * 196 + (1 - rq) * 24
        ra = rq * a
        c.drawRRect(rrect(14, y, 396, 172, 24), PF(CARD, 0.55 * ra))
        spath(c, rrect_path(14, y, 396, 172, 24), IVORY, 0.55 * ra, 1.8, dash=(10, 9), phase=-lt * 22)
        spath(c, ICONS[ic](66, y + 98, 62), IVORY, 0.88 * ra, 2.3, p=eo(pr(lt, 0.3 + k * 0.1, 0.45)), mode='par')
        text(c, ti, 114, y + 104, font('cond', 40), IVORY, ra)
        text(c, de, 114, y + 138, font('sans', 21), IVORY, 0.55 * ra)
        f = font('condm', 16)
        pw = tw('EM BREVE', f, 0.2) + 24
        c.drawRRect(rrect(392 - pw, y + 22, pw, 28, 14), PS(ORANGE, 0.85 * ra, 1.4))
        text(c, 'EM BREVE', 392 - pw + 12, y + 42, f, ORANGE, ra, track=0.2)


PAGE = (10, 128, 424, 790, 30)


def screen(c, t, g, a):
    """phone screen content, screen-local coordinates"""
    SW, SH = g['SW'], g['SH']
    c.save()
    c.clipRRect(rrect(g['SX'], g['SY'], SW, SH, 54), skia.ClipOp.kIntersect, True)
    c.translate(g['SX'], g['SY'])
    hq = eo(pr(t, S['f1'] + 0.35, 0.4))
    node(c, 40, 92, a=hq * a, s=0.85, glow=0.4)
    spath(c, circle_path(SW - 44, 92, 22), IVORY, 0.5 * a, 1.6, p=hq)
    text(c, 'SN', SW - 44, 99, font('sanssb', 18), IVORY, 0.8 * hq * a, align='c')
    k2 = eio(pr(t, S['f2'], 0.5))
    gk = eo(pr(t, S['f1'] + 0.45, 0.45)) * (1 - eo(pr(t, S['f2'], 0.25)))
    text(c, 'Bom dia,', 28, 166 + (1 - gk) * 12, font('sans', 28), IVORY, 0.55 * gk * a)
    text(c, 'Seu Negócio', 28, 220 + (1 - gk) * 12, font('cond', 54), IVORY, gk * a)
    fade1 = 1 - eo(pr(t, S['f2'], 0.25))
    if t < S['f2'] + 0.3:
        qa = eo(pr(t, S['f1'] + 0.55, 0.5))
        card_visib(c, t, 22, 258 + (1 - qa) * 26, qa * fade1 * a)
        qc = eo(pr(t, S['f1'] + 0.75, 0.5))
        card_tip(c, t, 22, 620 + (1 - qc) * 26, qc * fade1 * a)
        qi = eo(pr(t, S['f1'] + 0.85, 0.5))
        input_bar(c, t, 22, 794 + (1 - qi) * 26, qi * fade1 * a)
    # page (card B grows into the page used by F2/F3); pushed out to the left at F5
    qb = eo(pr(t, S['f1'] + 0.65, 0.5))
    push = eio(pr(t, S['f5'], 0.45))
    if qb > 0 and t < S['f5'] + 0.5:
        bx, by, bw, bh, br = 22, 450 + (1 - qb) * 26, 400, 152, 24
        px, py, pw, ph, prr = PAGE
        rx, ry, rw, rh, rr = lerp(bx, px, k2), lerp(by, py, k2), lerp(bw, pw, k2), lerp(bh, ph, k2), lerp(br, prr, k2)
        rx -= push * SW
        pa = qb * a
        c.drawRRect(rrect(rx, ry, rw, rh, rr), PF(CARD, (0.75 + 0.1 * k2) * pa))
        spath(c, rrect_path(rx, ry, rw, rh, rr), IVORY, 0.2 * pa, 1.4, p=eo(pr(t, S['f1'] + 0.65, 0.6)))
        c.save()
        c.clipRRect(rrect(rx, ry, rw, rh, rr), skia.ClipOp.kIntersect, True)
        inner = 1 - eo(pr(t, S['f2'], 0.2))
        if inner > 0:
            card_posts_inner(c, t, rx, ry, pa * inner)
        if t >= S['f2']:
            c.translate(rx, ry)
            sc = eio(pr(t, S['f3'], 0.55)) * 790
            if t < S['f3'] + 0.6:
                c.save(); c.translate(0, -sc); page_f2(c, t, pa); c.restore()
            if t >= S['f3']:
                c.save(); c.translate(0, 790 - sc); page_f3(c, t, pa); c.restore()
        c.restore()
    chip_end = None
    if t >= S['f4']:
        c.save()
        c.translate(-push * SW, 0)
        chip_end = sheet_f4(c, t, g, a)
        c.restore()
        if chip_end is not None:
            chip_end = (chip_end[0] - push * SW, chip_end[1])
    if t >= S['f5']:
        c.save()
        c.translate((1 - push) * SW + PAGE[0], PAGE[1])
        c.drawRRect(rrect(0, 0, PAGE[2], PAGE[3], PAGE[4]), PF(CARD, 0.85 * a))
        spath(c, rrect_path(0, 0, PAGE[2], PAGE[3], PAGE[4]), IVORY, 0.2 * a, 1.4)
        page_f5(c, t, a)
        c.restore()
    c.restore()
    return chip_end


FEATS = [(S['f1'], ['Um painel *só seu*.'], 'Veja tudo o que está sendo feito, quando quiser.'),
         (S['f2'], ['Escala de posts *pronta*.'], 'IA que conhece sua marca + revisão humana.'),
         (S['f3'], ['Seus números,', '*sem complicação*.'], 'O que funcionou e o que dá pra melhorar.'),
         (S['f4'], ['Assunto sério?', '*Gente de verdade* assume.'], 'Você recebe um plano no WhatsApp.'),
         (S['f5'], ['E *em breve*:', 'pedidos, notas e caixa.'], 'Tudo no mesmo painel.')]


def feature_text(c, t):
    ends = [f[0] for f in FEATS[1:]] + [S['end']]
    for (t0, lines, sub), t1 in zip(FEATS, ends):
        if not (t0 - 0.05 <= t <= t1 + 0.05):
            continue
        t_in = t0 + (0.55 if t0 == S['f1'] else 0.18)
        size = fit_size(lines, 84, 860)
        lh = size * 1.1
        y0 = 1318 if len(lines) == 1 else 1282
        headline(c, lines, t, t_in, t1 - 0.2, 540, y0, size, lh)
        q = eo(pr(t, t_in + 0.4, 0.45))
        o = eio(pr(t, t1 - 0.2, 0.2))
        ys = y0 + (len(lines) - 1) * lh + 64 + (1 - q) * 12 - o * 20
        text(c, sub, 540, ys, font('sans', 30), IVORY, 0.66 * q * (1 - o), align='c')


# ================================================================= tela final
def scene_end(c, t):
    lt = t - S['end']
    glow_blob(c, 540, 900, 640, ORANGE, 0.08 * eo(pr(lt, 0.2, 0.6)))
    letters(c, 'RUGE', 540, 770, font('cond', 206), lt, 0.15, stagger=0.05, dur=0.5, track=0.06, rise=50)
    sq = eo(pr(lt, 0.45, 0.4))
    text(c, 'MARKETING E SOLUÇÕES DIGITAIS', 540, 826 + (1 - sq) * 10, font('condm', 27), IVORY, 0.62 * sq, align='c', track=0.3)
    lq = eo(pr(lt, 0.5, 0.3))
    spath(c, poly([(540, 862), (540, 862 + 76 * lq)]), IVORY, 0.55, 1.6)
    nq = eob(pr(lt, 0.6, 0.35))
    if nq > 0:
        node(c, 540, 900, a=min(1, nq * 1.6), s=max(nq, 0.01), glow=0.8)
    letters(c, 'NEXO', 540, 1052, font('cond', 128), lt, 0.62, stagger=0.05, dur=0.5, track=0.18, rise=40, colors=NEXO_COLORS)
    headline(c, ['Dando voz à sua marca.'], t, S['end'] + 0.9, None, 540, 1150, 54, 60, base='sans', stagger=0.06)
    f = font('sansm', 31)
    s = 'Chama no direct  ·  @ruge.marketing'
    w = tw(s, f) + 70
    pq = eo(pr(lt, 1.15, 0.5))
    if pq > 0:
        spath(c, rrect_path(540 - w / 2, 1206, w, 72, 36), ORANGE, 0.9, 2, p=pq, glow=0.5)
        tq = eo(pr(lt, 1.3, 0.4))
        text(c, s, 540, 1253 + (1 - tq) * 8, f, IVORY, tq, align='c')


# ================================================================= frame
def render(t):
    surf = skia.Surface(W, H)
    c = surf.getCanvas()
    c.drawImage(BG, 0, 0)
    draw_dust(c, t)
    draw_net(c, t)
    # ---- dores
    if t < S['p2']:
        scene_p1(c, t)
    elif t < S['p3']:
        scene_p2(c, t)
    elif t < S['p3'] + WIPE:
        xw = W * eio(pr(t, S['p3'], WIPE))
        c.save(); c.clipRect(skia.Rect.MakeLTRB(xw, 0, W, H), skia.ClipOp.kIntersect, True); scene_p2(c, t); c.restore()
        c.save(); c.clipRect(skia.Rect.MakeLTRB(0, 0, xw, H), skia.ClipOp.kIntersect, True); scene_p3(c, t); c.restore()
        spath(c, poly([(xw, 0), (xw, H)]), ORANGE, 0.9, 2.4, glow=1.0, cap='butt')
        for yy in range(240, 1500, 120):
            c.drawLine(xw - 9, yy, xw + 9, yy, PS(IVORY, 0.55, 1.4))
    elif t < S['p4']:
        scene_p3(c, t)
    elif t < S['pv']:
        scene_p4(c, t)
    elif t < S['rv'] + IRIS:
        scene_pv(c, t)
    if S['p1'] <= t < S['pv'] + 0.3:
        kicker(c, t, 'JÁ PASSOU POR ISSO?', 0.0, S['pv'] - 0.15)
    heads = [(S['p1'], ['Postou…', 'e *ninguém* viu?']), (S['p2'], ['Sem tempo…', 'e sem *ideia* do que postar?']),
             (S['p3'], ['Paga alguém…', 'e não *vê* o que foi feito?']), (S['p4'], ['Pedidos, notas, caixa…', 'tudo *espalhado*?']),
             (S['pv'], ['E se tudo estivesse', '*conectado*?'])]
    ends = [h[0] for h in heads[1:]] + [S['rv']]
    for (t0, lines), t1 in zip(heads, ends):
        if t0 - 0.05 <= t <= t1 + 0.05:
            size = fit_size(lines, 90, 860)
            t_in = t0 + (0.18 if t0 == 0 else 0.22)
            headline(c, lines, t, t_in, t1 - 0.2, 540, 1290, size, size * 1.06)
    # ---- revelação (iris a partir do nó central)
    if S['rv'] <= t < S['rv'] + IRIS:
        r = 1250 * eio(pr(t, S['rv'], IRIS))
        c.save()
        c.clipPath(circle_path(*HUB, max(r, 0.5)), skia.ClipOp.kIntersect, True)
        c.drawImage(BG, 0, 0)
        draw_dust(c, t)
        draw_net(c, t)
        scene_rv(c, t)
        nexo_word(c, t)
        c.restore()
        spath(c, circle_path(*HUB, max(r, 0.5)), ORANGE, 0.95, 3, glow=1.0)
        spath(c, circle_path(*HUB, max(r * 0.93, 0.5)), IVORY, 0.3, 1.2)
    elif S['rv'] + IRIS <= t < S['f1'] + 0.4:
        scene_rv(c, t)
    # ---- painel
    chip_end = None
    if S['f1'] <= t < S['end'] + EXPAND:
        g = phone_geom(t)
        pa = 1 - eo(pr(t, S['end'], 0.3))
        draw_phone(c, t, g, pa)
        chip_end = screen(c, t, g, pa)
        if S['f4'] <= t:
            person_out(c, t, g, chip_end)
    if S['rv'] <= t < S['end'] + 0.35 and not (S['rv'] <= t < S['rv'] + IRIS):
        nexo_word(c, t)
    if S['f1'] - 0.05 <= t <= S['end'] + 0.05:
        feature_text(c, t)
    # ---- tela final (a tela do celular cresce até virar o quadro)
    if t >= S['end']:
        k = eio(pr(t, S['end'], EXPAND))
        g = phone_geom(t)
        rx, ry = lerp(g['SX'], -40, k), lerp(g['SY'], -40, k)
        rw, rh = lerp(g['SW'], W + 80, k), lerp(g['SH'], H + 80, k)
        rr = lerp(54, 0, k)
        c.save()
        c.clipRRect(rrect(rx, ry, rw, rh, rr), skia.ClipOp.kIntersect, True)
        c.drawImage(BG, 0, 0)
        draw_dust(c, t)
        scene_end(c, t)
        c.restore()
        if k < 1:
            spath(c, rrect_path(rx, ry, rw, rh, rr), IVORY, 0.55 * (1 - k), 1.6)
    corners(c, t)
    return surf.makeImageSnapshot().toarray()


def finish(arr, i):
    bgr = arr[:, :, :3].astype(np.int16)
    bgr += GRAIN[i % len(GRAIN)][:, :, None]
    return np.clip(bgr, 0, 255).astype(np.uint8)


if __name__ == '__main__':
    os.chdir(HERE)
    if sys.argv[1] == 'test':
        os.makedirs('test', exist_ok=True)
        for s in sys.argv[2:]:
            t = float(s)
            i = int(round(t * FPS))
            cv2.imwrite(f'test/t{t:05.2f}.jpg', finish(render(t), i), [cv2.IMWRITE_JPEG_QUALITY, 92])
        print('ok')
    else:
        a, b = int(sys.argv[1]), int(sys.argv[2])
        os.makedirs('out', exist_ok=True)
        for i in range(a, min(b, N)):
            cv2.imwrite(f'out/{i:04d}.jpg', finish(render(i / FPS), i), [cv2.IMWRITE_JPEG_QUALITY, 95])
        print('done', a, b)
