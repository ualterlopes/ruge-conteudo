"""Trilha e efeitos do story 15 s (100 BPM) — sintetizados, sem amostras. Reusa os instrumentos do sound.py.
Gera: story_mix.wav, story_musica_stem.wav, story_sfx_stem.wav
"""
import os, json, math
import numpy as np
import sound as SD
from sound import *          # noqa
from story import CH_IN, AWAKE, RES, END, FIN, DUR

OUT = DUR
NO = int(OUT * SR)


def music_story():
    mb, pads, drums = Bus(), Bus(), Bus()
    # A: dores (0 – 4,8) — lá menor, tic e pulso crescente
    A = [(0.0, [57, 60, 64], 45), (2.4, [53, 57, 60], 41)]
    for k, (t0, notes, root) in enumerate(A):
        pads.add(t0 - 0.05, pad_chord(notes, 2.75, 850 + 200 * k), 0.22)
        b = np.sin(2 * np.pi * mtof(root) * T(int(2.5 * SR))) * env_asr(int(2.5 * SR), 0.08, 0.35)
        mb.add(t0, b, 0.26)
        for e in range(8):
            if t0 + e * 0.3 < 0.5:
                continue
            n8 = int(0.28 * SR)
            pz = lp(saw(mtof(root + 12), n8), 700 + 140 * k) * env_ad(n8, 0.004, 0.09)
            mb.add(t0 + e * 0.3, pz, 0.05 + 0.02 * k + (0.012 if e % 2 == 0 else 0), pan=-0.2 if e % 2 else 0.2)
    for i in range(int(4.8 / 0.3)):
        t0 = i * 0.3
        if t0 < 0.6:
            continue
        on = i % 2 == 0
        drums.add(t0, tick(2600 if (i // 2) % 2 == 0 else 1950, 1.0), 0.10 if on else 0.055, pan=0.25 if on else -0.25)
    for t0 in (2.4, 3.0, 3.6, 4.2):      # coração acelerando
        drums.add(t0, kick(1.0, 120, 40, 0.5), 0.5)
        drums.add(t0 + 0.18, kick(1.0, 100, 38, 0.4), 0.3)
    # B: Nexo acorda (4,8 – 10,8) — dó maior, groove
    C = [(4.8, [60, 64, 67, 72], 36), (7.2, [59, 62, 67, 71], 43), (9.6, [57, 60, 64, 69], 45)]
    ARP = {36: [60, 64, 67, 72, 76, 72, 67, 64], 43: [59, 62, 67, 71, 74, 71, 67, 62], 45: [57, 60, 64, 69, 72, 69, 64, 60]}
    pads.add(4.75, pad_chord([55, 59, 62, 67], 0.9, 1600, att=0.2, rel=0.2), 0.2)
    for t0, notes, root in C:
        if t0 > 4.8:
            pads.add(t0 - 0.04, pad_chord(notes, 2.6, 2600, det=0.1, att=0.12, rel=0.35), 0.22)
        else:
            pads.add(5.4, pad_chord(notes, 1.8, 2600, det=0.1, att=0.2, rel=0.35), 0.22)
        for e in range(8):
            tt = t0 + e * 0.3
            if tt < 5.4 or tt >= END:
                continue
            mb.add(tt, bass(mtof(root), 0.27, 1.0), 0.30 if e % 2 == 0 else 0.22)
        for s16 in range(16):
            tt = t0 + s16 * 0.15
            if tt < 5.4 or tt >= END:
                continue
            pads.add(tt, pluck(mtof(ARP[root][s16 % 8] + 12), 0.45, 1.2), 0.075 if s16 % 4 else 0.1, pan=-0.35 if s16 % 2 else 0.35)
    for b in range(int((END - 5.4) / BEAT) + 1):
        tt = 5.4 + b * BEAT
        if tt >= END:
            break
        drums.add(tt, kick(1.0), 0.78) if b % 2 == 0 else drums.add(tt, clap(), 0.42)
        drums.add(tt, hat(False), 0.5)
        drums.add(tt + 0.3, hat(b % 4 == 3), 0.72)
    for k in range(8):                    # virada antes do cartão final
        drums.add(10.2 + k * 0.075, clap(0.6 + 0.4 * k / 8), 0.12 + 0.12 * k / 8)
    # D: cartão final — resolve em dó
    pads.add(END - 0.05, pad_chord([60, 64, 67, 72], 1.6, 2800, att=0.08, rel=0.4), 0.24)
    pads.add(END + 1.2, pad_chord([48, 60, 64, 67, 72, 76], 3.2, 3200, att=0.1, rel=1.6), 0.28)
    pads.add(FIN + 0.95, pad_chord([48, 55, 60, 64, 67, 72], 3.6, 3200, att=0.08, rel=2.0), 0.30)
    mb.add(FIN + 1.0, np.sin(2 * np.pi * mtof(36) * T(int(3.4 * SR))) * env_asr(int(3.4 * SR), 0.01, 2.4), 0.34)
    for k, m_ in enumerate((84, 88, 91)):
        pads.add(FIN + 1.5 + k * 0.2, bell(mtof(m_), 1.8), 0.09, pan=(-0.3, 0, 0.3)[k])
    mb.add(END + 1.2, np.sin(2 * np.pi * mtof(36) * T(int(3.0 * SR))) * env_asr(int(3.0 * SR), 0.01, 1.8), 0.32)
    for k, m in enumerate((76, 79, 84, 88)):
        pads.add(END + 1.2 + k * 0.15, bell(mtof(m), 1.8), 0.10, pan=(-0.4, -0.1, 0.1, 0.4)[k])
    wet = reverb(pads.x, decay=2.2, mix=0.32)
    duck = np.ones(N)
    for b in range(int((END - 5.4) / 1.2) + 1):
        i = int((5.4 + b * 1.2) * SR); k = int(0.25 * SR)
        if i + k < N:
            duck[i:i + k] = np.minimum(duck[i:i + k], 0.72 + 0.28 * np.linspace(0, 1, k) ** 0.7)
    out = (wet + mb.x) * duck[:, None] + reverb(drums.x, decay=0.7, mix=0.10)
    gap = np.ones(N)                     # respiro antes do "Já imaginou…"
    i0, i1 = int(4.66 * SR), int(4.8 * SR)
    gap[i0:i1] = np.linspace(1, 0.08, i1 - i0) ** 2
    j1 = int(5.0 * SR)
    gap[i1:j1] = 0.08 + 0.92 * np.linspace(0, 1, j1 - i1) ** 1.5
    return out * gap[:, None]


def sfx_story():
    fx = Bus()
    fx.add(0.0, scratch(0.6), 0.05)
    for k, t0 in enumerate(CH_IN):       # cada tarefa que cai: pop + alerta
        fx.add(t0, pop(420 + 30 * k, 900 + 40 * k, 0.1), 0.07, pan=-0.5 if k % 2 == 0 else 0.5)
        fx.add(t0 + 0.2, beep(1320, 0.07), 0.05 + 0.006 * k, pan=-0.3 if k % 2 == 0 else 0.3)
        fx.add(t0 + 0.2, tick(3000, 1.0, 0.03), 0.04)
    for t0 in (3.9, 4.15, 4.4):          # aperto crescente
        fx.add(t0, beep(660, 0.05), 0.06)
    # o Nexo acorda
    fx.add(AWAKE - 0.02, swell(392, 1.0) * 0.8, 0.07)
    fx.add(AWAKE + 0.02, glass(1568), 0.10)
    fx.add(AWAKE + 0.04, chime(1046, 1.4), 0.07)
    fx.add(AWAKE + 0.05, boom(1.2) * 0.4, 0.05)
    fx.add(6.3, pop(500, 800, 0.1), 0.05, pan=-0.6)       # caneca
    for k, t0 in enumerate(RES):
        fx.add(t0, marker(0.4), 0.06, pan=-0.4 if k % 2 == 0 else 0.4)
        fx.add(t0 + 0.30, tick(2400, 1.0, 0.04), 0.06)
        notes = (72, 76, 79, 84, 88, 91)
        fx.add(t0 + 0.35, pluck(mtof(notes[k] + 12), 0.5, 1.4), 0.14, pan=-0.4 if k % 2 == 0 else 0.4)
        fx.add(t0 + 0.38, chime(mtof(notes[k] + 24), 0.9), 0.05)
        fx.add(t0 + 0.55, tick(1800, 1.0, 0.03), 0.045)    # contador desce
    fx.add(RES[-1] + 0.65, glass(2093), 0.12)              # tudo em dia
    fx.add(RES[-1] + 0.65, chime(1568, 1.6), 0.09)
    # iris e cartão final
    fx.add(END - 0.02, boom(1.6), 0.16)
    fx.add(END - 0.02, growl(0.9) * 0.4, 0.05)
    fx.add(END, swell(262, 1.1), 0.09)
    for k in range(4):
        fx.add(END + 0.15 + k * 0.05, tick(3200 + 300 * k, 1.0, 0.03), 0.04)
    fx.add(END + 0.6, pop(520, 1100, 0.1), 0.08, pan=-0.2)            # nó
    for k in range(4):                                                  # NEXO
        fx.add(END + 0.62 + k * 0.05, pop(600 + 60 * k, 900, 0.07), 0.03)
    fx.add(END + 0.3, pop(700, 1250, 0.1), 0.08, pan=0.2)               # selo EM BREVE
    fx.add(END + 1.4, tick(2800, 1.0, 0.04), 0.05)
    fx.add(END + 1.15, glass(1568), 0.09)
    fx.add(END + 1.2, chime(1318, 2.0), 0.10)
    # 45% + EM BREVE
    fx.add(FIN - 0.05, swell(330, 1.0) * 0.8, 0.07)
    fx.add(FIN, boom(1.2) * 0.5, 0.07)
    for k in range(21):                                   # contador subindo
        fx.add(FIN + 0.25 + k * 0.05, tick(1800 + 90 * k, 1.0, 0.025), 0.045)
    fx.add(FIN + 1.3, chime(1568, 1.8), 0.10)
    fx.add(FIN + 1.3, glass(2093), 0.09)
    for k in range(8):                                    # letras do EM BREVE
        fx.add(FIN + 0.98 + k * 0.055, pop(500 + 55 * k, 800 + 40 * k, 0.07), 0.04, pan=-0.3 + 0.085 * k)
    fx.add(FIN + 1.0, boom(1.6), 0.18)
    fx.add(FIN + 1.0, growl(0.9) * 0.4, 0.05)
    fx.add(FIN + 1.9, tick(2800, 1.0, 0.04), 0.05)
    return fx.x


if __name__ == '__main__':
    os.chdir(SD.HERE)
    m = music_story()
    f = sfx_story()
    fade = np.ones(N)
    k = int(0.7 * SR)
    fade[NO - k:NO] = np.linspace(1, 0, k) ** 1.6
    fade[NO:] = 0
    m *= fade[:, None]
    f *= fade[:, None]
    f = f * 2.0
    mix = m + f
    pk = np.abs(mix).max()
    mix, m, f = mix / pk * 0.7, m / pk * 0.7, f / pk * 0.7
    cut = lambda x: x[:NO]
    mix, m, f = cut(mix), cut(m), cut(f)
    SD.write('_spre.wav', mix)
    I, tp = SD.lufs('_spre.wav')
    g = 10 ** ((-14.0 - I) / 20)
    mix, m, f = mix * g, m * g, f * g
    ceil = 10 ** (-1.6 / 20)
    SD.write('story_mix.wav', SD.limiter(mix, ceil=ceil))
    SD.write('story_musica_stem.wav', SD.limiter(m, ceil=ceil))
    SD.write('story_sfx_stem.wav', SD.limiter(f, ceil=ceil))
    I2, tp2 = SD.lufs('story_mix.wav')
    print(json.dumps({'pre_I': I, 'final_I': I2, 'final_TP': tp2}))
